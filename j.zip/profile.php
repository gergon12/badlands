<?php
require_once 'vendor/config.php';
session_start();
if(!isset($_SESSION["auth"])){
    header("Location: /login.php");
}
else{

    if (isset($_GET['pageno'])) {
        $pageno = $_GET['pageno'];
    } else {
        $pageno = 1;
    }
    $no_of_records_per_page = 10;
    $offset = ($pageno-1) * $no_of_records_per_page;

    $conn=mysqli_connect($host,$log,$pass,$dbname);
   
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        die();
    }
    
    $total_pages_sql = "SELECT COUNT(*) FROM statistic";
    $result = mysqli_query($conn,$total_pages_sql);
    $total_rows = mysqli_fetch_array($result)[0];
    $total_pages = ceil($total_rows / $no_of_records_per_page);

    $sql = "SELECT * FROM statistic ORDER BY id DESC LIMIT $offset , $no_of_records_per_page";
    $res_data = mysqli_query($conn,$sql);
    

}

?>

<?php

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">     
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Righteous&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;700;800&display=swap" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="//github.com/downloads/lafeber/world-flags-sprite/flags32.css"/>
    <title>Admin</title>
</head>
<body class="admin-profile">
    <div class="profile-main">
    <div class="nav-admin">
        <div><a href="/vendor/logout.php">LOGOUT</a></div>
    </div>
    <div class="file-div">
    <form action="vendor/upload.php" method="post" enctype="multipart/form-data" >
        <?php 
        $loaded_file_query = "SELECT * FROM file";
        $loaded_file = mysqli_query($conn,$loaded_file_query);
        $file_name = mysqli_fetch_array($loaded_file);

        echo "<h4>File now: " . str_ireplace("File/","",$file_name["name"]) . "</h4>";
        ?>
          <div class="form-dv">
          <!-- <div class="upload-div">
          <label for="file-upload" class="custom-file-upload">
           Choose your file
          </label>
          <input id="file-upload" type="file" name="myfile">
</div> -->
<!-- <h2>or</h2><br> -->
<label for="file_link" >
           File link
          </label>
<input  type="text" name="file_link" class="file_link">

          <div class="btn-div"><button type="submit" name="save">SAVE</button></div>    
          
          </div>
          
          
        </form>
    </div>
    <div class="stat-div">
    <h2 class="stat-title">Statistic</h2>
        <div>
            <!-- <p style="color:gray;">Downloads</p> -->
            <div class="stat-cols">
            <div class="stat-col-1">
                <div class="stat-col1-item1">
                <?php 
            $d = new DateTime(date("Y-m-d"));
            
            $d = $d->format('Y-m-d H:i:s');
            $d2 = new DateTime(date("Y-m-d"));
            $d2->modify('+1 day');
            $d2 = $d2->format('Y-m-d H:i:s');
            
             $sql_query_per_day = "SELECT COUNT(*) FROM statistic WHERE data BETWEEN '$d'   AND '$d2' ";
             $per_day_count = mysqli_query($conn,$sql_query_per_day);


             $d = new DateTime(date("Y-m-d"));
             $d->modify('-1 day');
             $d = $d->format('Y-m-d H:i:s');
             $d2 = new DateTime(date("Y-m-d"));
             $d2 = $d2->format('Y-m-d H:i:s');
             $sql_query_per_yesterday = "SELECT COUNT(*) FROM statistic WHERE data BETWEEN '$d'   AND '$d2' ";
             $per_yesterday_count = mysqli_query($conn,$sql_query_per_yesterday);


             $d = new DateTime(date("Y-m-d"));
             $d->modify('-7 day');
             $d = $d->format('Y-m-d H:i:s');
             $d2 = new DateTime(date("Y-m-d H:i:s"));
             $d2 = $d2->format('Y-m-d H:i:s');

             $sql_query_per_week = "SELECT COUNT(*) FROM statistic WHERE data BETWEEN '$d'   AND '$d2' ";
             $per_week_count = mysqli_query($conn,$sql_query_per_week);
            ?>
            <h3>For today</h3>
            <h1>
            <?php 
            //var_dump( );
            
            echo mysqli_fetch_array($per_day_count)[0];
            // echo $d->format('Y-m-d H:i:s');
            // echo "<p>". $total_rows . "</p>";
            ?></h1>
                </div>
                <div class="stat-col1-item2">
                <h3>For yesterday</h3>
                <h1>
                <?php 
                echo mysqli_fetch_array($per_yesterday_count)[0];
                ?>
                </h1>
                </div>
                <div class="stat-col1-item3">
                <h3>For week</h3>
                <h1>
                <?php 
                echo mysqli_fetch_array($per_week_count)[0];
                ?>
                </h1>
                </div>

                <div class="stat-col1-item4">
                <h3>For all the time</h3>
                    <h1>
            <?php 
          echo "<p>". $total_rows . "</p>";
        ?></h1>
                </div>
            
            
            
            </div>
            <div class="stat-col-2">

            </div>
            </div>
            
            
        </div>
        <!-- <div>
        <p style="color:gray;">Visitors</p>
            
        </div> -->
        
    </div>

    <div class="downloads-div">
        <h2 class="download-title">Downloads</h2>
    <?php


       
        // while($row = mysqli_fetch_array($res_data)){
        // echo "<p>".$row['ip']." ".$row['browser']." ".$row['data']." "."</p>";
        // }
        echo "<table class='table'>
        
          <tr>
            <th scope='col'>ID</th>
            <th scope='col'>IP</th>
            <th scope='col'>Country</th>
            <th scope='col'>BROWSER</th>
            <th scope='col'>OS</th>
            <th scope='col'>DATA</th>
          </tr>
        ";
        while($row = mysqli_fetch_array($res_data)){
            
            echo " <tr>
            <td>" . $row['id'] . "</td>
            <td>" . $row['ip'] . "</td>
            <td><div class='ip-flag'><ul class='f32'>    
            <li class='flag ".strtolower(ip_info($row['ip'], "Country Code")) ."'></li>  
            </ul>".ip_info($row['ip'], "Country")."</div></td>
            <td>" . $row['browser'] . "</td>
            <td>" . $row['os'] . "</td>
            <td>" . $row['data'] . "</td>
          </tr>
          ";
        }
          echo "
      </table>";
        mysqli_close($conn);
    ?>
    <ul class="pagination">
        <li><a href="?pageno=1">First</a></li>
        <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
        </li>
        <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
        </li>
        <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
    </ul>
    </div>

    </div>
    
    
</body>
</html>