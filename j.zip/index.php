<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><!--metatextblock--><title>Pagan Gods - Play to earn - Best NFT game</title><meta name="description" content="Blockchain game in a unique style of dark Slavic mythology. Play-to-Earn concept."><meta name="keywords" content="play to earn, nft games, pagan gods, play-to-ear, crypto games, blockchain games"><meta property="og:url" content=""><meta property="og:title" content="Pagan Gods"><meta property="og:description" content="Blockchain game in a unique style of dark Slavic mythology."><meta property="og:type" content="website"><meta property="og:image" content="images/haunted_forest_by_re.jpg"><link rel="canonical" href=""><!--/metatextblock--><meta property="fb:app_id" content="257953674358265"><meta name="format-detection" content="telephone=no"><meta http-equiv="x-dns-prefetch-control" content="on"><link rel="dns-prefetch" href="https://ws.tildacdn.com"><link rel="dns-prefetch" href="https://static.tildacdn.com"><link rel="dns-prefetch" href="https://fonts.tildacdn.com"><link rel="shortcut icon" href="favicon_1.ico" type="image/x-icon"><link rel="apple-touch-icon" href="images/Frame_332.png"><link rel="apple-touch-icon" sizes="76x76" href="images/Frame_332.png"><link rel="apple-touch-icon" sizes="152x152" href="images/Frame_332.png"><link rel="apple-touch-startup-image" href="https://static.tildacdn.com/tild3534-3535-4164-b135-343535643234/Frame_332.png"><meta name="msapplication-TileColor" content="#000000"><meta name="msapplication-TileImage" content="https://static.tildacdn.com/tild3264-3934-4365-a334-613432613934/Frame_332.png"><!-- Assets --><script async src="https://www.googletagmanager.com/gtm.js?id=GTM-TXDRMDW"></script><script async src="js/uF2g2cHkhckQ.js"></script><script async src="js/fbevents.js"></script><script src="js/tilda-fallback-1.0.min.js" charset="utf-8" async></script><link rel="stylesheet" href="css/tilda-grid-3.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';"><link rel="stylesheet" href="css/tilda-blocks-2.14.css" type="text/css" media="all" onerror="this.loaderr='y';"><link rel="stylesheet" href="css/tilda-animation-1.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';"><link rel="stylesheet" href="css/tilda-menusub-1.0.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';"><noscript><link rel="stylesheet" href="css/tilda-menusub-1.0.min.css" type="text/css" media="all"></noscript><link rel="stylesheet" href="css/tilda-cover-1.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';"><link rel="stylesheet" href="css/tilda-slds-1.4.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';"><noscript><link rel="stylesheet" href="css/tilda-slds-1.4.min.css" type="text/css" media="all"></noscript><link rel="stylesheet" href="css/tilda-zoom-2.0.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';"><noscript><link rel="stylesheet" href="css/tilda-zoom-2.0.min.css" type="text/css" media="all"></noscript><link rel="stylesheet" href="css/tilda-popup-1.1.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';"><noscript><link rel="stylesheet" href="css/tilda-popup-1.1.min.css" type="text/css" media="all"></noscript><link rel="stylesheet" href="css/tilda-feed-1.0.min.css" type="text/css" media="print" onload="this.media='all';" onerror="this.loaderr='y';"><noscript><link rel="stylesheet" href="css/tilda-feed-1.0.min.css" type="text/css" media="all"></noscript><link rel="stylesheet" href="css/tilda-forms-1.0.min.css" type="text/css" media="all" onerror="this.loaderr='y';"><script type="text/javascript">TildaFonts = ["167","168","169","170"];</script><script type="text/javascript" src="js/tilda-fonts.min.js" charset="utf-8" onerror="this.loaderr='y';"></script><script src="js/jquery-1.10.2.min.js" onerror="this.loaderr='y';"></script><script src="js/tilda-scripts-3.0.min.js" onerror="this.loaderr='y';"></script><script src="js/tilda-blocks-2.7.js" onerror="this.loaderr='y';"></script><script src="js/lazyload-1.3.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-animation-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-cover-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-events-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-menusub-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-slds-1.4.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/hammer.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-zoom-2.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-feed-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><script src="js/tilda-animation-sbs-1.0.min.js" charset="utf-8" async onerror="this.loaderr='y';"></script><!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '536453971463863');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=536453971463863&amp;ev=PageView&amp;noscript=1"></noscript>
<!-- End Facebook Pixel Code -->
<meta name="facebook-domain-verification" content="foc6k4s7scfqvkk1zoe9civfowi0ga">

<meta name="yandex-verification" content="abb3beae530ff3f1">
<link rel="stylesheet" href="main.css">	

	


<!-- AnyTrack Tracking Code -->
<script>!function(e,t,n,s,a){(a=t.createElement(n)).async=!0,a.src="https://assets.anytrack.io/uF2g2cHkhckQ.js",(t=t.getElementsByTagName(n)[0]).parentNode.insertBefore(a,t),e[s]=e[s]||function(){(e[s].q=e[s].q||[]).push(arguments)}}(window,document,"script","AnyTrack");</script>
<!-- End AnyTrack Tracking Code -->

<meta name="google-site-verification" content="O0yTb_7Bly6V5utbGTf8pS-uBV5vH0K37OaW4kE7PhY"><script type="text/javascript">window.dataLayer = window.dataLayer || [];</script><!-- Google Tag Manager --><script type="text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TXDRMDW');</script><!-- End Google Tag Manager --><!-- Facebook Pixel Code --><script type="text/javascript" data-tilda-cookie-type="advertising">setTimeout(function(){!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.agent='pltilda';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '536453971463863');
fbq('track', 'PageView');
}, 2000);</script><!-- End Facebook Pixel Code --><!-- VK Pixel Code --><script type="text/javascript" data-tilda-cookie-type="advertising">setTimeout(function(){!function(){var t=document.createElement("script");t.type="text/javascript",t.async=!0,t.src="https://vk.com/js/api/openapi.js?161",t.onload=function(){VK.Retargeting.Init("VK-RTRG-958739-gsQUs"),VK.Retargeting.Hit()},document.head.appendChild(t)}();
}, 2000);</script><!-- End VK Pixel Code --><script type="text/javascript">(function () {
if((/bot|google|yandex|baidu|bing|msn|duckduckbot|teoma|slurp|crawler|spider|robot|crawling|facebook/i.test(navigator.userAgent))===false && typeof(sessionStorage)!='undefined' && sessionStorage.getItem('visited')!=='y' && document.visibilityState){
var style=document.createElement('style');
style.type='text/css';
style.innerHTML='@media screen and (min-width: 980px) {.t-records {opacity: 0;}.t-records_animated {-webkit-transition: opacity ease-in-out .2s;-moz-transition: opacity ease-in-out .2s;-o-transition: opacity ease-in-out .2s;transition: opacity ease-in-out .2s;}.t-records.t-records_visible {opacity: 1;}}';
document.getElementsByTagName('head')[0].appendChild(style);
function t_setvisRecs(){
var alr=document.querySelectorAll('.t-records');
Array.prototype.forEach.call(alr, function(el) {
el.classList.add("t-records_animated");
});
setTimeout(function () {
Array.prototype.forEach.call(alr, function(el) {
el.classList.add("t-records_visible");
});
sessionStorage.setItem("visited", "y");
}, 400);
} 
document.addEventListener('DOMContentLoaded', t_setvisRecs);
}
})();</script><style type="text/css">@media screen and (min-width: 980px) {.t-records {opacity: 0;}.t-records_animated {-webkit-transition: opacity ease-in-out .2s;-moz-transition: opacity ease-in-out .2s;-o-transition: opacity ease-in-out .2s;transition: opacity ease-in-out .2s;}.t-records.t-records_visible {opacity: 1;}}</style></head><body class="t-body" style="margin:0;"><!--allrecords--><div id="allrecords" class="t-records t-records_animated t-records_visible" data-hook="blocks-collection-content-node" data-tilda-project-id="4028165" data-tilda-page-id="19534006" data-tilda-formskey="1376570edc7740832ec7c2e0d8e739c3" data-tilda-lazy="yes" data-tilda-project-headcode="yes"><div id="rec315366445" class="r t-rec t-screenmin-480px" style=" " data-animationappear="off" data-record-type="456" data-screen-min="480px"><!-- T456 --><div id="nav315366445marker"></div> <div class="t456__mobile"> <div class="t456__mobile_container"> <div class="t456__mobile_text t-name t-name_md" field="text"> </div> 
<div class="t456__burger"> <span></span> <span></span> <span></span> <span></span> </div> 
</div> </div><div id="nav315366445" class="t456 t456__hidden t456__positionfixed t456__beforeready" style="background-color: rgba(23,23,23,0.0); height:80px; " data-bgcolor-hex="#171717" data-bgcolor-rgba="rgba(23,23,23,0.0)" data-navmarker="nav315366445marker" data-appearoffset="50" data-bgopacity-two="90" data-menushadow="30" data-bgopacity="0.0" data-bgcolor-rgba-afterscroll="rgba(23,23,23,0.90)" data-menu-items-align="right" data-menu="yes"> <div class="t456__maincontainer t456__c12collumns" style="height:80px;"> <div class="t456__leftwrapper" style="padding-left:20px;min-width:120px;width:120px;"> <div style="display: block;"> <a href="#rec308851611" style="color:#ffffff;"> <img src="fonts/PG.svg" class="t456__imglogo t456__imglogomobile" imgfield="img" style="max-width: 120px; width: 120px;" alt> </a> </div> </div> <div class="t456__rightwrapper t456__menualign_right" style="padding-right:20px;"> 
<ul class="t456__list"> <li class="t456__list_item" style="padding:0 15px 0 0;"><a class="t-menu__link-item"  data-menu-submenu-hook target="_blank" style="color:#ffffff;font-weight:600;" data-menu-item-number="1">Guide</a> </li> <li class="t456__list_item" style="padding:0 15px;"><a class="t-menu__link-item" href="https://wax.atomichub.io/explorer/collection/pagangodsapp " data-menu-submenu-hook target="_blank" style="color:#ffffff;font-weight:600;" data-menu-item-number="2">Sale</a> </li> <li class="t456__list_item" style="padding:0 15px;"><a class="t-menu__link-item" href="" data-menu-submenu-hook style="color:#ffffff;font-weight:600;" data-menu-item-number="3">Pagan Gods Web</a> </li> <li class="t456__list_item" style="padding:0 15px;"><a class="t-menu__link-item" href="https://drive.google.com/file/d/1fAmL6rMpCxqjKMjVIFA5HYtFFP6G_cDO/view?usp=sharing" data-menu-submenu-hook target="_blank" style="color:#ffffff;font-weight:600;" data-menu-item-number="4">Whitepaper</a> </li> <li class="t456__list_item" style="padding:0 0 0 15px;"><a class="t-menu__link-item" href="" data-menu-submenu-hook style="color:#ffffff;font-weight:600;" data-menu-item-number="5">Ru</a> </li> </ul> 
</div> </div></div><style>@media screen and (max-width: 980px) {
#rec315366445 .t456__leftcontainer{
padding: 20px;
}
}
@media screen and (max-width: 980px) {
#rec315366445 .t456__imglogo{
padding: 20px 0;
}
}</style><script type="text/javascript"> 
$(document).ready(function() {
setTimeout(function(){
t456_highlight();
}, 500);
t456_checkAnchorLinks('315366445');
});
$(window).resize(function() {
t456_setBg('315366445');
});
$(document).ready(function() {
t456_setBg('315366445');
});
$(document).ready(function() {
$('.t456').removeClass('t456__beforeready');
t456_appearMenu('315366445');
$(window).bind('scroll', t_throttle(function(){t456_appearMenu('315366445')}, 200));
});
$(document).ready(function() {
t456_changebgopacitymenu('315366445');
$(window).bind('scroll', t_throttle(function(){t456_changebgopacitymenu('315366445')}, 200));
});
</script><script type="text/javascript"> 
$(document).ready(function() {
t456_createMobileMenu('315366445');
}); 
</script><style>#rec315366445 .t-menu__link-item{
}
@supports (overflow:-webkit-marquee) and (justify-content:inherit)
{
#rec315366445 .t-menu__link-item,
#rec315366445 .t-menu__link-item.t-active {
opacity: 1 !important;
}
}</style><script type="text/javascript"> $(document).ready(function() {
setTimeout(function(){
t_onFuncLoad('t_menusub_init', function() {
t_menusub_init('315366445');
});
}, 500);
});</script><style>@media screen and (max-width: 980px) {
#rec315366445 .t-menusub__menu .t-menusub__link-item {
color:#ffffff !important;
}
#rec315366445 .t-menusub__menu .t-menusub__link-item.t-active {
color:#ffffff !important;
}
}</style><!--[if IE 8]><style>#rec315366445 .t456 {
filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#D9171717', endColorstr='#D9171717');
}</style><![endif]--></div><div id="rec409298567" class="r t-rec t-screenmax-480px" style=" " data-animationappear="off" data-record-type="456" data-screen-max="480px"><!-- T456 --><div id="nav409298567marker"></div> <div class="t456__mobile"> <div class="t456__mobile_container"> <div class="t456__mobile_text t-name t-name_md" field="text"> </div> 
<div class="t456__burger"> <span></span> <span></span> <span></span> <span></span> </div> 
</div> </div><div id="nav409298567" class="t456 t456__hidden t456__positionfixed t456__beforeready" style="background-color: rgba(23,23,23,0.0); height:80px; " data-bgcolor-hex="#171717" data-bgcolor-rgba="rgba(23,23,23,0.0)" data-navmarker="nav409298567marker" data-appearoffset="1000" data-bgopacity-two="90" data-menushadow="30" data-bgopacity="0.0" data-bgcolor-rgba-afterscroll="rgba(23,23,23,0.90)" data-menu-items-align="center" data-menu="yes"> <div class="t456__maincontainer t456__c12collumns" style="height:80px;"> 
<div class="t456__rightwrapper t456__menualign_center" style="padding-right:20px;"> 
<ul class="t456__list"> <li class="t456__list_item" style="padding:0 15px 0 0;"><a class="t-menu__link-item" href="" data-menu-submenu-hook target="_blank" style="color:#ffffff;font-weight:600;" data-menu-item-number="1">Guide</a> </li> <li class="t456__list_item" style="padding:0 15px;"><a class="t-menu__link-item" href="https://wax.atomichub.io/explorer/collection/pagangodsapp " data-menu-submenu-hook target="_blank" style="color:#ffffff;font-weight:600;" data-menu-item-number="2">Sale</a> </li> <li class="t456__list_item" style="padding:0 15px;"><a class="t-menu__link-item" href="" data-menu-submenu-hook style="color:#ffffff;font-weight:600;" data-menu-item-number="3">Pagan Gods Web</a> </li> <li class="t456__list_item" style="padding:0 0 0 15px;"><a class="t-menu__link-item" href="https://drive.google.com/file/d/1fAmL6rMpCxqjKMjVIFA5HYtFFP6G_cDO/view?usp=sharing" data-menu-submenu-hook target="_blank" style="color:#ffffff;font-weight:600;" data-menu-item-number="4">Whitepaper</a> </li> </ul> 
</div> </div></div><style>@media screen and (max-width: 980px) {
#rec409298567 .t456__leftcontainer{
padding: 20px;
}
}
@media screen and (max-width: 980px) {
#rec409298567 .t456__imglogo{
padding: 20px 0;
}
}</style><script type="text/javascript"> 
$(document).ready(function() {
t456_setListMagin('409298567','flase');
});
$(document).ready(function() {
setTimeout(function(){
t456_highlight();
}, 500);
t456_checkAnchorLinks('409298567');
});
$(window).resize(function() {
t456_setBg('409298567');
});
$(document).ready(function() {
t456_setBg('409298567');
});
$(document).ready(function() {
$('.t456').removeClass('t456__beforeready');
t456_appearMenu('409298567');
$(window).bind('scroll', t_throttle(function(){t456_appearMenu('409298567')}, 200));
});
$(document).ready(function() {
t456_changebgopacitymenu('409298567');
$(window).bind('scroll', t_throttle(function(){t456_changebgopacitymenu('409298567')}, 200));
});
</script><script type="text/javascript"> 
$(document).ready(function() {
t456_createMobileMenu('409298567');
}); 
</script><style>#rec409298567 .t-menu__link-item{
}
@supports (overflow:-webkit-marquee) and (justify-content:inherit)
{
#rec409298567 .t-menu__link-item,
#rec409298567 .t-menu__link-item.t-active {
opacity: 1 !important;
}
}</style><script type="text/javascript"> $(document).ready(function() {
setTimeout(function(){
t_onFuncLoad('t_menusub_init', function() {
t_menusub_init('409298567');
});
}, 500);
});</script><style>@media screen and (max-width: 980px) {
#rec409298567 .t-menusub__menu .t-menusub__link-item {
color:#ffffff !important;
}
#rec409298567 .t-menusub__menu .t-menusub__link-item.t-active {
color:#ffffff !important;
}
}
@media screen and (min-width: 981px) { #rec409298567 .t-menusub__menu {
text-align:center; }
}</style><!--[if IE 8]><style>#rec409298567 .t456 {
filter: progid:DXImageTransform.Microsoft.gradient(startColorStr='#D9171717', endColorstr='#D9171717');
}</style><![endif]--></div><div id="rec348942238" class="r t-rec t-screenmin-480px" style=" " data-animationappear="off" data-record-type="206" data-screen-min="480px"><!-- cover --><div class="t-cover" id="recorddiv348942238" bgimgfield="img" style="height:100vh; background-image:url(&#x27;images/__1.jpeg&#x27;);"><div class="t-cover__carrier" id="coverCarry348942238" data-content-cover-id="348942238" data-content-cover-bg="https://static.tildacdn.com/tild3038-3465-4163-b031-373866326535/_.jpeg" data-content-cover-height="100vh" data-content-cover-parallax="fixed" style="height:100vh; "></div> <div class="t-cover__filter" style="height:100vh;background-image: -moz-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: -webkit-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: -o-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: -ms-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));filter: progid:DXImageTransform.Microsoft.gradient(startColorStr=&#x27;#cc000000&#x27;, endColorstr=&#x27;#4c000000&#x27;);"></div><div class="t-container"> <div class="t-col t-col_12"><div class="t-cover__wrapper t-valign_middle" style="height:100vh; position: relative;z-index: 1;"> <div class="t183"> <div data-hook-content="covercontent"> <div class="t183__wrapper"> <div class="t183__uptitle t-uptitle t-uptitle_xxl t-animate" data-animate-style="fadeindown" data-animate-group="yes" style="text-transform:uppercase;" field="subtitle">Fight. Win. Earn.</div> <h1 class="t183__title t-title t-title_xl t-animate" data-animate-style="fadeindown" data-animate-group="yes" style field="title"><div style="font-size:52px;" data-customstyle="yes"><span style="font-family: Circe;">Unique dark slavic mythology <br></span>NFT-based blockchain game<br></div></h1> <div class="t183__buttons"> <a href="/download-page.php" target="_blank" class="t-btn t-animate" data-btneffects-first="btneffects-light" data-animate-style="fadeindown" data-animate-group="yes" style="color:#000000;background-color:#ffbb00;border-radius:100px; -moz-border-radius:100px; -webkit-border-radius:100px;"><table style="width:100%; height:100%;"><tbody><tr><td >PLAY
        </td></tr></tbody></table></a> </div> </div> </div> </div> </div> </div> </div> </div> <style>#rec348942238 .t-btn[data-btneffects-first],
#rec348942238 .t-btn[data-btneffects-second],
#rec348942238 .t-submit[data-btneffects-first],
#rec348942238 .t-submit[data-btneffects-second] {
position: relative;
overflow: hidden;
-webkit-transform: translate3d(0,0,0);
transform: translate3d(0,0,0);
}
#rec348942238 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects,
#rec348942238 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
-webkit-transform: translateX(-60px);
-ms-transform: translateX(-60px);
transform: translateX(-60px);
-webkit-animation-name: light;
animation-name: light;
-webkit-animation-duration: 4s;
animation-duration: 4s;
-webkit-animation-timing-function: ease;
animation-timing-function: ease;
-webkit-animation-iteration-count: infinite;
animation-iteration-count: infinite;
}
#rec348942238 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md,
#rec348942238 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md {
-webkit-animation-name: light-md;
animation-name: light-md;
}
#rec348942238 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg,
#rec348942238 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg {
-webkit-animation-name: light-lg;
animation-name: light-lg;
}
#rec348942238 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_effects,
#rec348942238 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_effects {
position: absolute;
top: 0;
left: 0;
width: 60px;
height: 100%;
background: -webkit-gradient(linear, left top, right top, from(rgba(255, 255, 255, 0)), color-stop(50%, rgba(255,255,255, 0.5)), to(rgba(255, 255, 255, 0)));
background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: -o-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
}
@-webkit-keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
#rec348942238 .t-btn[data-btneffects-second="btneffects-light"] .t-btn_wrap-effects,
#rec348942238 .t-submit[data-btneffects-second="btneffects-light"] .t-btn_wrap-effects {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
-webkit-transform: translateX(-60px);
-ms-transform: translateX(-60px);
transform: translateX(-60px);
-webkit-animation-name: light;
animation-name: light;
-webkit-animation-duration: 4s;
animation-duration: 4s;
-webkit-animation-timing-function: ease;
animation-timing-function: ease;
-webkit-animation-iteration-count: infinite;
animation-iteration-count: infinite;
}
#rec348942238 .t-btn[data-btneffects-second="btneffects-light"] .t-btn_wrap-effects_md,
#rec348942238 .t-submit[data-btneffects-second="btneffects-light"] .t-btn_wrap-effects_md {
-webkit-animation-name: light-md;
animation-name: light-md;
}
#rec348942238 .t-btn[data-btneffects-second="btneffects-light"] .t-btn_wrap-effects_lg,
#rec348942238 .t-submit[data-btneffects-second="btneffects-light"] .t-btn_wrap-effects_lg {
-webkit-animation-name: light-lg;
animation-name: light-lg;
}
#rec348942238 .t-btn[data-btneffects-second="btneffects-light"] .t-btn_effects,
#rec348942238 .t-submit[data-btneffects-second="btneffects-light"] .t-btn_effects {
position: absolute;
top: 0;
left: 0;
width: 60px;
height: 100%;
background: -webkit-gradient(linear, left top, right top, from(rgba(255, 255, 255, 0)), color-stop(50%, rgba(255,255,255, 0.5)), to(rgba(255, 255, 255, 0)));
background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: -o-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
}
@-webkit-keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}</style><script>$(document).ready(function() {
$('#rec348942238 .t-btn[data-btneffects-first], #rec348942238 .t-submit[data-btneffects-first]').append('<div class="t-btn_wrap-effects"><div class="t-btn_effects"></div></div>');
if ($('#rec348942238 .t-btn[data-btneffects-first]').outerWidth() > 230) {
$('#rec348942238 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec348942238 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_md');
}
if ($('#rec348942238 .t-btn[data-btneffects-first], #rec348942238 .t-submit').outerWidth() > 300) {
$('#rec348942238 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec348942238 .t-submit[data-btneffects-first] .t-btn_wrap-effects').removeClass('t-btn_wrap-effects_md');
$('#rec348942238 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec348942238 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_lg');
}
$('#rec348942238 .t-btn[data-btneffects-second], #rec348942238 .t-submit[data-btneffects-second]').append('<div class="t-btn_wrap-effects"><div class="t-btn_effects"></div></div>');
if ($('#rec348942238 .t-btn[data-btneffects-second]').outerWidth() > 230) {
$('#rec348942238 .t-btn[data-btneffects-second] .t-btn_wrap-effects, #rec348942238 .t-submit[data-btneffects-second] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_md');
}
if ($('#rec348942238 .t-btn[data-btneffects-second], #rec348942238 .t-submit').outerWidth() > 300) {
$('#rec348942238 .t-btn[data-btneffects-second] .t-btn_wrap-effects, #rec348942238 .t-submit[data-btneffects-second] .t-btn_wrap-effects').removeClass('t-btn_wrap-effects_md');
$('#rec348942238 .t-btn[data-btneffects-second] .t-btn_wrap-effects, #rec348942238 .t-submit[data-btneffects-second] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_lg');
}
});</script></div><div id="rec425124207" class="r t-rec t-screenmax-480px" style=" " data-animationappear="off" data-record-type="396" data-screen-max="480px"><!-- T396 --><style>#rec425124207 .t396__artboard{min-height: 550px;height: 100vh; background-color: #171717;}#rec425124207 .t396__filter{min-height: 550px;height: 100vh;background-image: -webkit-gradient( linear, left top, left bottom, from(rgba(0,0,0,0)), to(rgba(0,0,0,0)) );background-image: -webkit-linear-gradient(top, rgba(0,0,0,0), rgba(0,0,0,0));background-image: linear-gradient(to bottom, rgba(0,0,0,0), rgba(0,0,0,0));}#rec425124207 .t396__carrier{min-height: 550px;height: 100vh;background-position: center center;background-attachment: scroll;background-image: url('images/________YouTube.png');background-size:cover;background-repeat:no-repeat;}@media screen and (max-width: 1199px){#rec425124207 .t396__artboard{}#rec425124207 .t396__filter{}#rec425124207 .t396__carrier{background-attachment:scroll;}}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){#rec425124207 .t396__artboard{min-height: 660px;height: 90vh; }#rec425124207 .t396__filter{min-height: 660px;height: 90vh;background-image: -webkit-gradient( linear, left top, left bottom, from(rgba(0,0,0,0.7)), to(rgba(0,0,0,0.65)) );background-image: -webkit-linear-gradient(top, rgba(0,0,0,0.7), rgba(0,0,0,0.65));background-image: linear-gradient(to bottom, rgba(0,0,0,0.7), rgba(0,0,0,0.65));background-color: unset;}#rec425124207 .t396__carrier{min-height: 660px;height: 90vh;background-position: center center;}}#rec425124207 .tn-elem[data-elem-id="1470209944682"]{color:#ffffff;text-align:center;z-index:2;top: calc(50vh - 0px + 46px);left: calc(50% - 580px + 0px);width:1160px;}#rec425124207 .tn-elem[data-elem-id="1470209944682"] .tn-atom{color:#ffffff;font-size:72px;font-family:'Arial',Arial,sans-serif;line-height:1.2;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec425124207 .tn-elem[data-elem-id="1470209944682"]{top: calc(50vh - 0px + 49px);left: calc(50% - 470px + 0px);width:940px;}#rec425124207 .tn-elem[data-elem-id="1470209944682"] .tn-atom{font-size:68px;line-height:1.15;}}@media screen and (max-width: 959px){#rec425124207 .tn-elem[data-elem-id="1470209944682"]{top: calc(50vh - 0px + 56px);left: calc(50% - 310px + 0px);width:620px;}#rec425124207 .tn-elem[data-elem-id="1470209944682"] .tn-atom{line-height:1;letter-spacing:0.5px;}}@media screen and (max-width: 639px){#rec425124207 .tn-elem[data-elem-id="1470209944682"]{top: calc(50vh - 0px + 73px);left: calc(50% - 230px + 0px);width:460px;}#rec425124207 .tn-elem[data-elem-id="1470209944682"] .tn-atom{font-size:32px;}}@media screen and (max-width: 479px){#rec425124207 .tn-elem[data-elem-id="1470209944682"]{top: calc(330vh - 0px + -30px);left: calc(50% - 150px + 0px);width:300px;}#rec425124207 .tn-elem[data-elem-id="1470209944682"] .tn-atom{font-size:30px;}}#rec425124207 .tn-elem[data-elem-id="1643983202322"]{color:#ffffff;text-align:center;z-index:5;top: calc(50vh - 275px + 20px);left: calc(50% - 600px + 20px);width:200px;height:55px;}#rec425124207 .tn-elem[data-elem-id="1643983202322"] .tn-atom{color:#ffffff;font-size:14px;font-family:'Arial',Arial,sans-serif;line-height:1.55;font-weight:600;border-radius:30px;background-color:#000000;background-position:center center;border-color:transparent;border-style:solid;transition: background-color 0.2s ease-in-out, color 0.2s ease-in-out, border-color 0.2s ease-in-out;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){#rec425124207 .tn-elem[data-elem-id="1643983202322"]{top: calc(318px);left: calc(50% - 160px + 75px);width:170px;height:50px;}#rec425124207 .tn-elem[data-elem-id="1643983202322"]{color:#000000;}#rec425124207 .tn-elem[data-elem-id="1643983202322"] .tn-atom{color:#000000;font-size:15px;background-color:#ffbb00;}}#rec425124207 .tn-elem[data-elem-id="1643984466296"]{z-index:7;top: calc(50vh - 275px + 195px);left: calc(50% - 600px + 10px);width:200px;}#rec425124207 .tn-elem[data-elem-id="1643984466296"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){#rec425124207 .tn-elem[data-elem-id="1643984466296"]{top: calc(660px + 28px);left: calc(50% - 160px + -73px);width:205px;}}#rec425124207 .tn-elem[data-elem-id="1643984657828"]{z-index:9;top: calc(50vh - 275px + 40px);left: calc(50% - 600px + 297px);width:200px;}#rec425124207 .tn-elem[data-elem-id="1643984657828"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){#rec425124207 .tn-elem[data-elem-id="1643984657828"]{top: calc(660px + 30px);left: calc(50% + 160px - 223px + 73px);width:223px;}}#rec425124207 .tn-elem[data-elem-id="1647613211497"]{z-index:10;top: calc(50vh - 0px + -151px);left: calc(50% - 102px + 0px);width:204px;}#rec425124207 .tn-elem[data-elem-id="1647613211497"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec425124207 .tn-elem[data-elem-id="1647613211497"]{top: calc(50vh - 0px + -145px);left: calc(50% - 102px + 0px);}}@media screen and (max-width: 959px){#rec425124207 .tn-elem[data-elem-id="1647613211497"]{top: calc(50vh - 0px + -127px);left: calc(50% - 102px + 0px);}}@media screen and (max-width: 639px){#rec425124207 .tn-elem[data-elem-id="1647613211497"]{top: calc(50vh - 0px + -100px);left: calc(50% - 102px + 0px);}}@media screen and (max-width: 479px){#rec425124207 .tn-elem[data-elem-id="1647613211497"]{top: calc(330vh - 0px + -184px);left: calc(50% - 125px + 0px);width:250px;}}#rec425124207 .tn-elem[data-elem-id="1647613211510"]{color:#000000;z-index:11;top: calc(50vh - 275px + 20px);left: calc(50% - 600px + 20px);width:560px;}#rec425124207 .tn-elem[data-elem-id="1647613211510"] .tn-atom{color:#000000;font-size:20px;font-family:'Circe',Arial,sans-serif;line-height:1.55;font-weight:400;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){#rec425124207 .tn-elem[data-elem-id="1647613211510"]{top: calc(211px);left: calc(50% - 160px + 24px);width:272px;}#rec425124207 .tn-elem[data-elem-id="1647613211510"]{color:#fcf9f9;text-align:center;}#rec425124207 .tn-elem[data-elem-id="1647613211510"] .tn-atom{color:#fcf9f9;font-size:18px;line-height:1.25;letter-spacing:0px;}}</style> 
<div class="t396"><div class="t396__artboard" data-artboard-recid="425124207" data-artboard-height="550" data-artboard-height-res-320="660" data-artboard-height_vh="100" data-artboard-height_vh-res-320="90" data-artboard-valign="center" data-artboard-upscale="grid" data-artboard-ovrflw> <div class="t396__carrier t-bgimg" data-artboard-recid="425124207" data-original="https://static.tildacdn.com/tild6363-3433-4662-b639-623130623263/________YouTube.png"></div> 
<div class="t396__filter" data-artboard-recid="425124207"></div> 
<div class="t396__elem tn-elem tn-elem__4251242071470209944682" data-elem-id="1470209944682" data-elem-type="text" data-field-top-value="46" data-field-top-res-960-value="49" data-field-top-res-640-value="56" data-field-top-res-480-value="73" data-field-top-res-320-value="-30" data-field-left-value="0" data-field-left-res-960-value="0" data-field-left-res-640-value="0" data-field-left-res-480-value="0" data-field-left-res-320-value="0" data-field-width-value="1160" data-field-width-res-960-value="940" data-field-width-res-640-value="620" data-field-width-res-480-value="460" data-field-width-res-320-value="300" data-field-axisy-value="center" data-field-axisx-value="center" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1470209944682"></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__4251242071643983202322" data-elem-id="1643983202322" data-elem-type="button" data-field-top-value="20" data-field-top-res-320-value="318" data-field-left-value="20" data-field-left-res-320-value="75" data-field-height-value="55" data-field-height-res-320-value="50" data-field-width-value="200" data-field-width-res-320-value="170" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value> 
<a class="tn-atom js-click-zero-stat"href="/download-page.php" target="_blank" data-tilda-event-name="/tilda/click/rec425124207/button1643983202322">PLAY</a> 
</div> 
<div class="t396__elem tn-elem tn-elem__4251242071643984466296" data-elem-id="1643984466296" data-elem-type="image" data-field-top-value="195" data-field-top-res-320-value="28" data-field-left-value="10" data-field-left-res-320-value="-73" data-field-width-value="200" data-field-width-res-320-value="205" data-field-axisy-value="top" data-field-axisy-res-320-value="bottom" data-field-axisx-value="left" data-field-axisx-res-320-value="left" data-field-container-value="grid" data-field-container-res-320-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-field-filewidth-value="1680" data-field-fileheight-value="2376"> 
<div class="tn-atom"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3162-3866-4664-b736-663238633537/witch_1ev.png" imgfield="tn_img_1643984466296"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__4251242071643984657828" data-elem-id="1643984657828" data-elem-type="image" data-field-top-value="40" data-field-top-res-320-value="30" data-field-left-value="297" data-field-left-res-320-value="73" data-field-width-value="200" data-field-width-res-320-value="223" data-field-axisy-value="top" data-field-axisy-res-320-value="bottom" data-field-axisx-value="left" data-field-axisx-res-320-value="right" data-field-container-value="grid" data-field-container-res-320-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-field-filewidth-value="1680" data-field-fileheight-value="2376"> 
<div class="tn-atom"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3666-6662-4936-a463-313034343733/svyatogor_1.png" imgfield="tn_img_1643984657828"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__4251242071647613211497" data-elem-id="1647613211497" data-elem-type="image" data-field-top-value="-151" data-field-top-res-960-value="-145" data-field-top-res-640-value="-127" data-field-top-res-480-value="-100" data-field-top-res-320-value="-184" data-field-left-value="0" data-field-left-res-960-value="0" data-field-left-res-640-value="0" data-field-left-res-480-value="0" data-field-left-res-320-value="0" data-field-width-value="204" data-field-width-res-320-value="250" data-field-axisy-value="center" data-field-axisx-value="center" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-field-filewidth-value="680" data-field-fileheight-value="264"> 
<div class="tn-atom"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3466-6563-4730-b934-363061633662/PG.svg" imgfield="tn_img_1647613211497"> </div> 
</div> 
<div class="t396__elem tn-elem 1122 tn-elem__4251242071647613211510" data-elem-id="1647613211510" data-elem-type="text" data-field-top-value="20" data-field-top-res-320-value="211" data-field-left-value="20" data-field-left-res-320-value="24" data-field-width-value="560" data-field-width-res-320-value="272" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1647613211510"><span style="font-weight: 600;">DARK SLAVIC MYTHOLOGY BLOCKCHAIN GAME</span></div> 
</div> 
</div> </div> <script>$( document ).ready(function() { 
t396_init('425124207'); 
});</script><!-- /T396 --></div><div id="rec315366450" class="r t-rec t-rec_pt_90 t-rec_pb_45 t-screenmin-480px" style="padding-top:90px;padding-bottom:45px;background-color:#171717; " data-animationappear="off" data-record-type="844" data-screen-min="480px" data-bg-color="#171717"><!-- t844 --><div class="t844"><div class="t-section__container t-container"><div class="t-col t-col_12"><div class="t-section__topwrapper t-align_left"><h2 class="t-section__title t-title t-title_xs t-animate" data-animate-style="fadeinright" data-animate-group="yes" field="btitle"><div style="font-size:52px;text-align:center;color:#ffffff;" data-customstyle="yes"><span style="font-weight: 700;">Play-to-Earn concept</span></div></h2></div></div></div><div class="t-container"> <div class="t844__col t-col t-col_4 t-align_left t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> 
<img src="images/noroot.png" data-original="https://static.tildacdn.com/tild3939-3030-4662-b637-663564336365/noroot.png" class="t844__img t-img" imgfield="li_img__1531137278040" style="width:80px;"> <div class="t844__wrapperleft "> <div class="t-heading t-heading_md" style="color:#ffffff;font-weight:700;" field="li_title__1531137278040">Play <br></div> <div class="t-descr t-descr_sm" style="color:#ffffff;" field="li_descr__1531137278040">While heading somewhere or sitting at home on a silken couch; laptop or smartphone - it doesn't matter, everyone will find suitable conditions to be happy with!<br></div> </div> </div> <div class="t844__col t-col t-col_4 t-align_left t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> 
<img src="images/noroot_2.png" data-original="https://static.tildacdn.com/tild3539-6261-4537-b364-336661383935/noroot.png" class="t844__img t-img" imgfield="li_img__1531137250635" style="width:80px;"> <div class="t844__wrapperleft "> <div class="t-heading t-heading_md" style="color:#ffffff;font-weight:700;" field="li_title__1531137250635">Earn</div> <div class="t-descr t-descr_sm" style="color:#ffffff;" field="li_descr__1531137250635">We are in favor of the idea that our users deserve the finer things: the time spent in game must be converted into real money! Play, sell the obtained trophies and enjoy the profit.<br></div> </div> </div> <div class="t844__col t-col t-col_4 t-align_left t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> 
<img src="images/noroot_1.png" data-original="https://static.tildacdn.com/tild3266-3330-4361-b662-336163646135/noroot.png" class="t844__img t-img" imgfield="li_img__1531137263951" style="width:80px;"> <div class="t844__wrapperleft "> <div class="t-heading t-heading_md" style="color:#ffffff;font-weight:700;" field="li_title__1531137263951">Trade<br></div> <div class="t-descr t-descr_sm" style="color:#ffffff;" field="li_descr__1531137263951">The obtained NFT-cards and our FUR token can be stored, sold and exchanged for real currency. It's all in your hands!<br></div> </div> </div></div></div></div><div id="rec408883396" class="r t-rec t-rec_pt_90 t-rec_pb_45 t-screenmax-480px" style="padding-top:90px;padding-bottom:45px;background-color:#171717; " data-animationappear="off" data-record-type="844" data-screen-max="480px" data-bg-color="#171717"><!-- t844 --><div class="t844"><div class="t-section__container t-container"><div class="t-col t-col_12"><div class="t-section__topwrapper t-align_center"><h1 class="t-section__title t-title t-title_xs t-animate" data-animate-style="fadeinright" data-animate-group="yes" field="btitle"><div style="font-size:52px;color:#ffffff;" data-customstyle="yes"><span style="font-weight: 700;">Play-to-Earn concept</span></div></h1></div></div></div><div class="t-container"> <div class="t844__col t-col t-col_4 t-align_center t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> 
<img src="images/noroot.png" data-original="https://static.tildacdn.com/tild3939-3030-4662-b637-663564336365/noroot.png" class="t844__img t-img" imgfield="li_img__1531137278040" style="width:80px;"> <div class="t844__wrappercenter "> <div class="t-heading t-heading_md" style="color:#ffffff;font-weight:700;" field="li_title__1531137278040">Play <br></div> <div class="t-descr t-descr_sm" style="color:#ffffff;" field="li_descr__1531137278040">While heading somewhere or sitting at home on a silken couch; laptop or smartphone - it doesn't matter, everyone will find suitable conditions to be happy with!<br></div> </div> </div> <div class="t844__col t-col t-col_4 t-align_center t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> 
<img src="images/noroot_2.png" data-original="https://static.tildacdn.com/tild3539-6261-4537-b364-336661383935/noroot.png" class="t844__img t-img" imgfield="li_img__1531137250635" style="width:80px;"> <div class="t844__wrappercenter "> <div class="t-heading t-heading_md" style="color:#ffffff;font-weight:700;" field="li_title__1531137250635">Earn</div> <div class="t-descr t-descr_sm" style="color:#ffffff;" field="li_descr__1531137250635">We are in favor of the idea that the time spent in game must be converted into real money! Play, sell the obtained trophies and enjoy the profit.<br></div> </div> </div> <div class="t844__col t-col t-col_4 t-align_center t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> 
<img src="images/noroot_1.png" data-original="https://static.tildacdn.com/tild3266-3330-4361-b662-336163646135/noroot.png" class="t844__img t-img" imgfield="li_img__1531137263951" style="width:80px;"> <div class="t844__wrappercenter "> <div class="t-heading t-heading_md" style="color:#ffffff;font-weight:700;" field="li_title__1531137263951">Trade<br></div> <div class="t-descr t-descr_sm" style="color:#ffffff;" field="li_descr__1531137263951">The obtained NFT-cards and our FUR token can be stored, sold and exchanged for real currency. <br>It's all in your hands!<br></div> </div> </div></div></div></div><div id="rec315366452" class="r t-rec" style=" " data-animationappear="off" data-record-type="674"><!-- T674 --><div class="t674"><img class="t674__img-holder" src="images/_.jpg"></div><style>body {
background-color:#dbdbdb;
}
.t674__body_with-bg:after {
content: "";
position: fixed;
top: 0;
left: 0;
right: 0;
bottom: 0;
z-index: -1;
-webkit-overflow-scrolling: touch;
background-image: url('images/_.jpg');
background-repeat: no-repeat;
background-position: center;
-webkit-background-size: cover;
background-size: cover;
min-height: 100%;
height: 100vh;
background-attachment: initial;
-webkit-transform: translate3d(0,0,0);
transform: translate3d(0,0,0);
transition: all 0.2s linear;
}</style><script>$(document).ready(function() {
t674_init('315366452');
});</script></div><div id="rec315366454" class="r t-rec t-rec_pt_0 t-rec_pb_45 t-screenmin-480px" style="padding-top:0px;padding-bottom:45px;background-color:#171717; " data-record-type="493" data-screen-min="480px" data-bg-color="#171717"><!-- t493 --><div class="t493"><div class="t-section__container t-container"><div class="t-col t-col_12"><div class="t-section__topwrapper t-align_left"><div class="t-section__title t-title t-title_xs t-animate" data-animate-style="fadeinright" data-animate-group="yes" field="btitle"><div style="font-size:52px;color:#ffffff;" data-customstyle="yes"></div></div></div></div></div> <div class="t493__container t-container"><div class="t493__flex-wrapper"> <div class="t493__box-img-mobile t-col"> <div class="t493__tablewrapper"> <div class="t493__cell t-cell"> <img class="t493__img t-margin_auto t-img" src="images/Group_2601.png" data-original="https://static.tildacdn.com/tild3339-3730-4064-a430-653131333363/Group_2601.png" imgfiled="img5"> </div> </div> </div> <div class="t493__box-text t-col t-col_flex t-valign_middle t-col_5 "> <div class="t493__tablewrapper"> <div class="t493__cell t-cell"> <div class="t493__item t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> <div class="t493__textwrapper t-cell t-valign_top"> <div class="t493__heading t-heading t-heading_sm " style="color:#ffbb00;font-weight:700;" field="title"> <span style="font-weight: 700;">PVE</span></div> <div class="t493__descr t-descr t-descr_xs " style="color:#ffffff;font-weight:500;" field="descr"> <div style="font-size:18px;" data-customstyle="yes">Send your sellswords on a treasure hunt, win battles and obtain unique NFT cards<br></div></div> </div> </div> <div class="t493__item t493__item_padding-top t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> <div class="t493__textwrapper t-cell t-valign_top"> <div class="t493__heading t-heading t-heading_sm " style="color:#ffbb00;font-weight:700;" field="title2"> Mining</div> <div class="t493__descr t-descr t-descr_xs " style="color:#ffffff;font-weight:500;" field="descr2"> <div style="font-size:18px;" data-customstyle="yes">Mine resources, develop your village & warriors and become stronger<br></div></div> </div> </div> <div class="t493__item t493__item_padding-top t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> <div class="t493__textwrapper t-cell t-valign_top"> <div class="t493__heading t-heading t-heading_sm " style="color:#ffbb00;font-weight:700;" field="title3"> PVP <span style="font-size: 24px;"><span style="font-weight: 400;" data-redactor-style="font-weight: 400;"><span style="font-size: 22px;">(coming soon)</span></span></span></div> <div class="t493__descr t-descr t-descr_xs " style="color:#ffffff;font-weight:500;" field="descr3"> <div style="font-size:18px;" data-customstyle="yes">Engage in battles with other wayfarers for glory and gold, then exchange your loot for real money!<br></div></div> </div> </div> </div> </div> </div> <div class="t493__box-img t-col t-col_flex t-valign_middle t-col_6 t-prefix_1"> <div class="t493__tablewrapper"> <div class="t493__cell t-cell"> <img class="t493__img t-img t-animate" data-animate-style="fadeinright" data-animate-group="yes" src="images/Group_2601.png" data-original="https://static.tildacdn.com/tild3339-3730-4064-a430-653131333363/Group_2601.png" imgfield="img5"> </div> </div> </div> </div> </div></div></div><div id="rec410824234" class="r t-rec t-rec_pt_0 t-rec_pb_45 t-screenmax-480px" style="padding-top:0px;padding-bottom:45px;background-color:#171717; " data-record-type="493" data-screen-max="480px" data-bg-color="#171717"><!-- t493 --><div class="t493"><div class="t-section__container t-container"><div class="t-col t-col_12"><div class="t-section__topwrapper t-align_left"><div class="t-section__title t-title t-title_xs t-animate" data-animate-style="fadeinright" data-animate-group="yes" field="btitle"><div style="font-size:52px;color:#ffffff;" data-customstyle="yes"></div></div></div></div></div> <div class="t493__container t-container"><div class="t493__flex-wrapper"> <div class="t493__box-img-mobile t-col"> <div class="t493__tablewrapper"> <div class="t493__cell t-cell"> <img class="t493__img t-margin_auto t-img" src="images/Group_2601_1.png" data-original="https://static.tildacdn.com/tild3032-3665-4262-b165-633435653963/Group_2601.png" imgfiled="img5"> </div> </div> </div> <div class="t493__box-text t-col t-col_flex t-valign_middle t-col_5 "> <div class="t493__tablewrapper"> <div class="t493__cell t-cell"> <div class="t493__item t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> <div class="t493__textwrapper t-cell t-valign_top"> <div class="t493__heading t-heading t-heading_sm " style="color:#ffbb00;font-weight:700;" field="title"> <span style="font-weight: 700;">PVE</span></div> <div class="t493__descr t-descr t-descr_xs " style="color:#ffffff;font-size:12px;font-weight:500;" field="descr"> <div style="font-size:14px;" data-customstyle="yes"><span style="font-weight: 100;">Send your sellswords on a treasure hunt, win battles and obtain unique NFT cards</span><br></div></div> </div> </div> <div class="t493__item t493__item_padding-top t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> <div class="t493__textwrapper t-cell t-valign_top"> <div class="t493__heading t-heading t-heading_sm " style="color:#ffbb00;font-weight:700;" field="title2"> Mining</div> <div class="t493__descr t-descr t-descr_xs " style="color:#ffffff;font-size:12px;font-weight:500;" field="descr2"> <div style="font-size:14px;" data-customstyle="yes"><span style="font-weight: 100;">Mine resources, develop your village & warriors and become stronger</span><br></div></div> </div> </div> <div class="t493__item t493__item_padding-top t-item t-animate" data-animate-style="fadeinright" data-animate-chain="yes"> <div class="t493__textwrapper t-cell t-valign_top"> <div class="t493__heading t-heading t-heading_sm " style="color:#ffbb00;font-weight:700;" field="title3"> PVP <span style="font-size: 24px;"><span style="font-weight: 400;" data-redactor-style="font-weight: 400;"><span style="font-size: 22px;">(coming soon)</span></span></span></div> <div class="t493__descr t-descr t-descr_xs " style="color:#ffffff;font-size:12px;font-weight:500;" field="descr3"> <div style="font-size:14px;" data-customstyle="yes"><span style="font-weight: 100;">Engage in battles with other wayfarers for glory and gold, then exchange your loot for real money!</span><br></div></div> </div> </div> </div> </div> </div> <div class="t493__box-img t-col t-col_flex t-valign_middle t-col_6 t-prefix_1"> <div class="t493__tablewrapper"> <div class="t493__cell t-cell"> <img class="t493__img t-img t-animate" data-animate-style="fadeinright" data-animate-group="yes" src="images/Group_2601_1.png" data-original="https://static.tildacdn.com/tild3032-3665-4262-b165-633435653963/Group_2601.png" imgfield="img5"> </div> </div> </div> </div> </div></div></div><div id="rec411801462" class="r t-rec t-rec_pb_0 t-screenmin-480px" style="padding-bottom:0px; " data-animationappear="off" data-record-type="1003" data-screen-min="480px"><!-- cover --><div class="t1003" style="min-height: 40px;"> <div class="t1003__outer"> <div class="t1003__wrapper" style data-marquee-speed="4.5" data-auto-correct-mobile-width="false"> <div class="t1003__content-wrapper" style="background-color: #ffbb00;height: 40px;" data-auto-correct-mobile-width="false"> <div class="t1003__content" data-auto-correct-mobile-width="false"> <div class="t1003__item" data-auto-correct-mobile-width="false"> <a class="t1003__item-link" href="https://t.me/pagangodsnews" target="_blank"> <div class="t-text t-text_md t1003__item-txt" style="padding: 0 10px;color:#171717;font-size:16px;font-weight:600;font-family:&#x27;Circe&#x27;;"> EVENT SALE SOON
</div> </a> <svg role="presentation" width="6" height="6" viewBox="0 0 10 8" style="margin-left: 30px; margin-right: 30px;" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="5.11351" cy="4" rx="4.16918" ry="4" fill="#171717"/></svg> </div> </div> </div> </div> </div></div><style> </style><script> t_onReady(function() {
t_onFuncLoad('t1003_init', function() {t1003_init('411801462', '');});
});</script></div><div id="rec315366455" class="r t-rec t-rec_pt_75 t-rec_pb_0 t-screenmin-480px" style="padding-top:75px;padding-bottom:0px;background-color:#171717; " data-record-type="795" data-screen-min="480px" data-bg-color="#171717"><!-- T795 --><div class="t795"> <div class="t-container t-align_center"> <div class="t-col t-col_10 t-prefix_1"> <div class="t795__title t-title t-title_xs t-margin_auto t-animate" data-animate-style="fadeinright" data-animate-group="yes" data-animate-order="1" field="title" style="color:#ffffff;"><div style="font-size:52px;" data-customstyle="yes"> Start your own <span style="color: rgb(255, 187, 0);">NFT collection</span> <br></div></div> </div> </div></div></div><div id="rec410232051" class="r t-rec t-rec_pt_30 t-rec_pb_0 t-screenmax-480px" style="padding-top:30px;padding-bottom:0px;background-color:#171717; " data-record-type="795" data-screen-max="480px" data-bg-color="#171717"><!-- T795 --><div class="t795"> <div class="t-container t-align_center"> <div class="t-col t-col_10 t-prefix_1"> <div class="t795__title t-title t-title_xs t-margin_auto t-animate" data-animate-style="fadeinright" data-animate-group="yes" data-animate-order="1" field="title" style="color:#ffffff;"><div style="font-size:52px;" data-customstyle="yes"> Start your own <br><span style="color: rgb(255, 187, 0);">NFT collection</span> <br></div></div> </div> </div></div></div><div id="rec411578678" class="r t-rec t-rec_pt_0 t-rec_pb_0 t-screenmin-480px" style="padding-top:0px;padding-bottom:0px;background-color:#171717; " data-animationappear="off" data-record-type="603" data-screen-min="480px" data-bg-color="#171717"><!-- t603--><div class="t603"> <div class="t603__container t603__container_indent" style="padding: 0px 20px 40px 20px;"> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__0" data-zoom-target="0" data-original="https://static.tildacdn.com/tild6436-3662-4635-b430-333031313430/Bogatyr_1ev_Shoulder.png" style="background: url(&#x27;images/Bogatyr_1ev_Shoulder.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild6436-3662-4635-b430-333031313430/Bogatyr_1ev_Shoulder.png"></div> </div> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__1" data-zoom-target="1" data-original="https://static.tildacdn.com/tild6538-6336-4263-a264-643533333630/Koschey_1ev_Curse.png" style="background: url(&#x27;images/Koschey_1ev_Curse.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild6538-6336-4263-a264-643533333630/Koschey_1ev_Curse.png"></div> </div> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__2" data-zoom-target="2" data-original="https://static.tildacdn.com/tild3037-3630-4636-b933-356165313265/Sirirn_1ev_Bloodsuck.png" style="background: url(&#x27;images/Sirirn_1ev_Bloodsuck.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild3037-3630-4636-b933-356165313265/Sirirn_1ev_Bloodsuck.png"></div> </div> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__3" data-zoom-target="3" data-original="https://static.tildacdn.com/tild6234-3866-4432-a438-353137623066/Raven_0ev_Witch.png" style="background: url(&#x27;images/Raven_0ev_Witch.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild6234-3866-4432-a438-353137623066/Raven_0ev_Witch.png"></div> </div> </div></div><style> 
@media screen and (max-width: 960px) {
#rec411578678 .t603__container.t-container, #rec411578678 .t603__container {
padding: 0px 10px 20px 10px !important;
}
#rec411578678 .t603__tile {
padding: 20px 10px 0px 10px !important;
}
}</style></div><div id="rec411806261" class="r t-rec t-rec_pt_0 t-rec_pb_0 t-screenmax-480px" style="padding-top:0px;padding-bottom:0px;background-color:#171717; " data-animationappear="off" data-record-type="603" data-screen-max="480px" data-bg-color="#171717"><!-- t603--><div class="t603"> <div class="t603__container t603__container_indent" style="padding: 0px 20px 40px 20px;"> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__0" data-zoom-target="0" data-original="https://static.tildacdn.com/tild6436-3662-4635-b430-333031313430/Bogatyr_1ev_Shoulder.png" style="background: url(&#x27;images/Bogatyr_1ev_Shoulder.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild6436-3662-4635-b430-333031313430/Bogatyr_1ev_Shoulder.png"></div> </div> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__1" data-zoom-target="1" data-original="https://static.tildacdn.com/tild6538-6336-4263-a264-643533333630/Koschey_1ev_Curse.png" style="background: url(&#x27;images/Koschey_1ev_Curse.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild6538-6336-4263-a264-643533333630/Koschey_1ev_Curse.png"></div> </div> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__2" data-zoom-target="2" data-original="https://static.tildacdn.com/tild6234-3866-4432-a438-353137623066/Raven_0ev_Witch.png" style="background: url(&#x27;images/Raven_0ev_Witch.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild6234-3866-4432-a438-353137623066/Raven_0ev_Witch.png"></div> </div> <div class="t603__tile t603__tile_25" style="padding:40px 20px 0px 20px;" itemscope itemtype="http://schema.org/ImageObject"> <div class="t603__blockimg t603__blockimg_9-16 t-bgimg t-animate" data-animate-style="zoomin" data-animate-chain="yes" bgimgfield="gi_img__3" data-zoom-target="3" data-original="https://static.tildacdn.com/tild3037-3630-4636-b933-356165313265/Sirirn_1ev_Bloodsuck.png" style="background: url(&#x27;images/Sirirn_1ev_Bloodsuck.png&#x27;) center center no-repeat; background-size:cover;"><meta itemprop="image" content="https://static.tildacdn.com/tild3037-3630-4636-b933-356165313265/Sirirn_1ev_Bloodsuck.png"></div> </div> </div></div><style> 
@media screen and (max-width: 960px) {
#rec411806261 .t603__container.t-container, #rec411806261 .t603__container {
padding: 0px 10px 20px 10px !important;
}
#rec411806261 .t603__tile {
padding: 20px 10px 0px 10px !important;
}
}</style></div><div id="rec348941368" class="r t-rec t-rec_pt_45 t-rec_pb_60" style="padding-top:45px;padding-bottom:60px;background-color:#171717; " data-record-type="191" data-bg-color="#171717"><!-- T142 --><div class="t142"><div class="t-container_100"> <div class="t142__wrapone"><div class="t142__wraptwo"> <a href="" target="_blank" data-tilda-event-name="/tilda/click/rec348941368/button1" class="js-click-stat"> <div class="t-btn t142__submit t-animate" data-animate-style="fadeindown" style="color:#000000;background-color:#ffbb00;border-radius:30px; -moz-border-radius:30px; -webkit-border-radius:30px;" data-btneffects-first="btneffects-light"> <span class="t142__text">BUY NFT-CARDS</span> </div> </a> </div> </div></div></div><script>t_onReady(function() {
t_onFuncLoad('t142_checkSize', function(){t142_checkSize('348941368');});
});
window.addEventListener('load', function(){
t_onFuncLoad('t142_checkSize', function(){t142_checkSize('348941368');});
});</script><style>#rec348941368 .t-btn[data-btneffects-first],
#rec348941368 .t-btn[data-btneffects-second],
#rec348941368 .t-submit[data-btneffects-first],
#rec348941368 .t-submit[data-btneffects-second] {
position: relative;
overflow: hidden;
-webkit-transform: translate3d(0,0,0);
transform: translate3d(0,0,0);
}
#rec348941368 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects,
#rec348941368 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
-webkit-transform: translateX(-60px);
-ms-transform: translateX(-60px);
transform: translateX(-60px);
-webkit-animation-name: light;
animation-name: light;
-webkit-animation-duration: 4s;
animation-duration: 4s;
-webkit-animation-timing-function: ease;
animation-timing-function: ease;
-webkit-animation-iteration-count: infinite;
animation-iteration-count: infinite;
}
#rec348941368 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md,
#rec348941368 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md {
-webkit-animation-name: light-md;
animation-name: light-md;
}
#rec348941368 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg,
#rec348941368 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg {
-webkit-animation-name: light-lg;
animation-name: light-lg;
}
#rec348941368 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_effects,
#rec348941368 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_effects {
position: absolute;
top: 0;
left: 0;
width: 60px;
height: 100%;
background: -webkit-gradient(linear, left top, right top, from(rgba(255, 255, 255, 0)), color-stop(50%, rgba(255,255,255, 0.5)), to(rgba(255, 255, 255, 0)));
background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: -o-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
}
@-webkit-keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}</style><script>$(document).ready(function() {
$('#rec348941368 .t-btn[data-btneffects-first], #rec348941368 .t-submit[data-btneffects-first]').append('<div class="t-btn_wrap-effects"><div class="t-btn_effects"></div></div>');
if ($('#rec348941368 .t-btn[data-btneffects-first]').outerWidth() > 230) {
$('#rec348941368 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec348941368 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_md');
}
if ($('#rec348941368 .t-btn[data-btneffects-first], #rec348941368 .t-submit').outerWidth() > 300) {
$('#rec348941368 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec348941368 .t-submit[data-btneffects-first] .t-btn_wrap-effects').removeClass('t-btn_wrap-effects_md');
$('#rec348941368 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec348941368 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_lg');
}
});</script></div><div id="rec348944188" class="r t-rec" style=" " data-animationappear="off" data-record-type="391"><!-- T391 --><!-- cover --><div class="t-cover" id="recorddiv348944188" bgimgfield="img" style="height:70vh; background-image:url(&#x27;images/_.jpeg&#x27;);"><div class="t-cover__carrier" id="coverCarry348944188" data-content-cover-id="348944188" data-content-cover-bg="https://static.tildacdn.com/tild6238-6338-4837-a233-663438623237/_.jpeg" data-content-cover-height="70vh" data-content-cover-parallax style="height:70vh;background-attachment:scroll; "></div> <div class="t-cover__filter" style="height:70vh;background-image: -moz-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: -webkit-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: -o-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: -ms-linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));background-image: linear-gradient(top, rgba(0,0,0,0.20), rgba(0,0,0,0.70));filter: progid:DXImageTransform.Microsoft.gradient(startColorStr=&#x27;#cc000000&#x27;, endColorstr=&#x27;#4c000000&#x27;);"></div><div class="t391"> <div class="t-container"> <div class="t391__firstcol t-col t-col_5 t-prefix_1"> <div class="t-cover__wrapper t-valign_middle" style="height: 70vh;"> <div class="t391__textwrapper t-align_left" data-hook-content="covercontent"> <div class="t391__title t-title t-title_xs t-animate" data-animate-style="fadeinright" data-animate-group="yes" data-animate-order="1" style field="title"><div style="font-size:38px;color:#ffffff;" data-customstyle="yes"><strong>Step into the dark path and get the secret treasure first!</strong></div></div> <div class="t391__text t-descr t-descr_sm t-animate" data-animate-style="fadeinright" data-animate-group="yes" data-animate-order="2" data-animate-delay="0.2" style field="text"><div style="font-size:18px;color:#ffffff;" data-customstyle="yes"></div></div> <div class="t391__buttonwrapper"> <div class="t391__btn t-animate" data-animate-style="zoomin" data-animate-group="yes" data-animate-order="3" data-animate-delay="0.3" style="margin-right: 10px;"> <a href="https://apps.apple.com/app/pagan-gods/id1577541460" target="_blank"> 
<svg role="presentation" viewBox="0 0 195 56" height="48px"><g fill="none" fill-rule="evenodd"><path d="M189.385 56H5.623C2.52 56 0 53.488 0 50.387V5.62C0 2.52 2.52 0 5.623 0h183.76C192.49 0 195 2.52 195 5.62v44.767c0 3.1-2.51 5.613-5.615 5.613z" fill="#000"/><path d="M42.585 28.924c-.042-4.712 3.86-7.004 4.037-7.11-2.21-3.222-5.633-3.662-6.836-3.697-2.876-.302-5.666 1.72-7.13 1.72-1.495 0-3.75-1.69-6.182-1.64-3.13.047-6.056 1.86-7.66 4.672-3.314 5.73-.843 14.16 2.33 18.8 1.59 2.27 3.444 4.8 5.872 4.71 2.376-.1 3.264-1.52 6.13-1.52 2.84 0 3.675 1.51 6.15 1.45 2.55-.04 4.156-2.28 5.688-4.57 1.835-2.6 2.572-5.17 2.6-5.3-.06-.02-4.95-1.89-5-7.54zm-4.678-13.857c1.278-1.598 2.152-3.772 1.91-5.978-1.85.08-4.163 1.28-5.495 2.84-1.178 1.38-2.23 3.63-1.96 5.76 2.078.15 4.212-1.05 5.545-2.63zm39.06 30.993h-3.32l-1.82-5.716h-6.32l-1.733 5.715h-3.232l6.263-19.46h3.868l6.294 19.45zm-5.687-8.114l-1.645-5.08c-.174-.52-.5-1.74-.98-3.665h-.06c-.19.83-.5 2.05-.923 3.67l-1.616 5.08h5.224zm21.794.926c0 2.386-.645 4.272-1.934 5.656-1.155 1.233-2.59 1.848-4.3 1.848-1.85 0-3.177-.664-3.985-1.99h-.06v7.39H79.68v-15.13c0-1.5-.04-3.04-.116-4.617h2.74l.175 2.22h.05c1.04-1.68 2.61-2.51 4.73-2.51 1.65 0 3.03.65 4.14 1.96 1.11 1.31 1.66 3.03 1.66 5.17zm-3.175.114c0-1.366-.31-2.49-.93-3.377-.68-.93-1.58-1.39-2.72-1.39-.77 0-1.47.25-2.09.76-.63.51-1.04 1.18-1.23 2.01-.1.38-.15.7-.15.95v2.34c0 1.02.31 1.88.94 2.58.62.7 1.44 1.05 2.44 1.05 1.17 0 2.08-.46 2.74-1.36.65-.91.98-2.1.98-3.58zm19.31-.114c0 2.386-.65 4.272-1.94 5.656-1.16 1.233-2.59 1.848-4.3 1.848-1.85 0-3.18-.664-3.99-1.99h-.06v7.39h-3.11v-15.13c0-1.5-.04-3.04-.12-4.617h2.74l.17 2.22h.05c1.04-1.68 2.61-2.51 4.73-2.51 1.65 0 3.03.65 4.14 1.96 1.1 1.31 1.66 3.03 1.66 5.17zm-3.18.114c0-1.366-.31-2.49-.93-3.377-.68-.93-1.58-1.39-2.72-1.39-.77 0-1.47.25-2.1.76s-1.04 1.18-1.23 2.01c-.1.38-.15.7-.15.95v2.34c0 1.02.31 1.88.93 2.58.62.7 1.44 1.05 2.44 1.05 1.17 0 2.09-.46 2.74-1.36.65-.91.98-2.1.98-3.58zm21.21 1.617c0 1.655-.58 3-1.73 4.04-1.27 1.137-3.04 1.704-5.3 1.704-2.1 0-3.77-.404-5.05-1.212l.72-2.598c1.37.828 2.87 1.243 4.5 1.243 1.17 0 2.09-.266 2.74-.796.65-.53.98-1.24.98-2.125 0-.79-.27-1.46-.81-2s-1.43-1.04-2.69-1.51c-3.41-1.27-5.11-3.14-5.11-5.58 0-1.6.59-2.91 1.79-3.93 1.19-1.03 2.78-1.54 4.76-1.54 1.77 0 3.24.31 4.41.92l-.78 2.54c-1.094-.6-2.334-.9-3.72-.9-1.1 0-1.956.27-2.57.81-.52.48-.78 1.07-.78 1.76 0 .77.3 1.4.895 1.9.52.46 1.463.96 2.83 1.5 1.676.67 2.905 1.46 3.696 2.36.79.9 1.18 2.02 1.18 3.37zm10.3-6.233h-3.44v6.81c0 1.733.61 2.598 1.82 2.598.56 0 1.02-.048 1.38-.144l.1 2.366c-.61.23-1.42.346-2.42.346-1.23 0-2.2-.376-2.89-1.126-.7-.752-1.04-2.012-1.04-3.782v-7.072H129v-2.34h2.045V29.46l3.06-.924v3.493h3.438v2.34zm15.5 4.56c0 2.155-.62 3.926-1.85 5.31-1.29 1.426-3.01 2.136-5.14 2.136-2.06 0-3.7-.683-4.92-2.048-1.23-1.366-1.84-3.09-1.84-5.167 0-2.17.63-3.95 1.89-5.33 1.26-1.38 2.96-2.08 5.09-2.08 2.06 0 3.72.69 4.97 2.05 1.19 1.33 1.79 3.04 1.79 5.14zm-3.24.1c0-1.294-.28-2.404-.84-3.33-.66-1.12-1.59-1.678-2.8-1.678-1.26 0-2.21.56-2.86 1.68-.56.926-.84 2.053-.84 3.386 0 1.294.27 2.404.83 3.328.67 1.12 1.61 1.678 2.83 1.678 1.19 0 2.12-.57 2.8-1.708.57-.943.86-2.064.86-3.356zm13.36-4.26c-.31-.056-.64-.085-.99-.085-1.1 0-1.95.413-2.54 1.242-.52.73-.78 1.655-.78 2.77v7.362h-3.12l.03-9.62c0-1.62-.04-3.09-.12-4.42h2.71l.11 2.68h.09c.33-.92.85-1.67 1.56-2.22.69-.5 1.44-.75 2.25-.75.29 0 .55.02.78.05v2.97zm13.94 3.61c0 .56-.04 1.03-.12 1.414h-9.35c.03 1.386.49 2.446 1.35 3.177.79.66 1.8.99 3.06.99 1.38 0 2.64-.22 3.78-.66l.49 2.17c-1.33.58-2.9.87-4.71.87-2.18 0-3.89-.64-5.13-1.92-1.24-1.28-1.86-2.99-1.86-5.15 0-2.11.57-3.88 1.73-5.28 1.21-1.5 2.84-2.25 4.9-2.25 2.023 0 3.553.75 4.593 2.25.82 1.19 1.234 2.67 1.234 4.42zm-2.98-.808c.02-.924-.19-1.722-.61-2.396-.54-.867-1.37-1.3-2.48-1.3-1.02 0-1.85.423-2.48 1.27-.52.675-.83 1.483-.92 2.425h6.49v.01zm-103.9-22.94c0 1.72-.52 3.017-1.55 3.887-.96.8-2.32 1.2-4.07 1.2-.87 0-1.62-.04-2.24-.12v-9.4c.81-.13 1.69-.2 2.63-.2 1.68 0 2.94.36 3.79 1.09.96.82 1.43 2 1.43 3.53zm-1.62.044c0-1.116-.3-1.97-.89-2.568-.59-.595-1.46-.893-2.59-.893-.49 0-.9.032-1.24.1v7.147c.19.03.53.043 1.03.043 1.17 0 2.08-.326 2.713-.978.64-.653.96-1.603.96-2.85zm10.18 1.46c0 1.06-.3 1.93-.91 2.61-.64.7-1.48 1.05-2.53 1.05-1.01 0-1.82-.335-2.42-1.008-.6-.67-.9-1.517-.9-2.538 0-1.067.31-1.943.93-2.623.62-.68 1.46-1.02 2.5-1.02 1.01 0 1.822.335 2.44 1.006.582.652.88 1.494.88 2.523zm-1.59.05c0-.636-.14-1.18-.41-1.636-.32-.55-.78-.825-1.38-.825-.61 0-1.08.275-1.4.825-.27.455-.41 1.01-.41 1.664 0 .636.14 1.18.41 1.636.33.55.8.824 1.39.824.59 0 1.05-.28 1.38-.84.28-.462.42-1.012.42-1.648zm13.07-3.44l-2.15 6.894h-1.4l-.9-3c-.23-.75-.41-1.49-.55-2.23h-.03c-.13.757-.32 1.498-.55 2.226l-.94 2.993h-1.42l-2.03-6.9h1.58l.78 3.28c.19.77.34 1.51.47 2.21h.03c.11-.58.3-1.31.57-2.2l.97-3.29h1.25l.934 3.22c.23.78.41 1.54.554 2.27h.04c.107-.71.26-1.47.47-2.27l.84-3.22h1.5zm7.94 6.894h-1.5v-3.95c0-1.217-.46-1.825-1.39-1.825-.46 0-.82.167-1.11.502-.28.333-.43.728-.43 1.18v4.088h-1.53v-4.92c0-.607-.02-1.263-.05-1.974h1.344l.07 1.08h.04c.18-.33.45-.61.797-.83.415-.25.88-.39 1.39-.39.64 0 1.177.21 1.603.63.53.51.794 1.27.794 2.29v4.13zm4.22 0h-1.53V9.584h1.53V19.64zm9.02-3.504c0 1.06-.31 1.93-.91 2.61-.64.7-1.48 1.05-2.53 1.05-1.01 0-1.82-.335-2.42-1.008-.6-.67-.9-1.517-.9-2.538 0-1.067.3-1.943.92-2.623.62-.68 1.453-1.02 2.5-1.02 1.015 0 1.83.335 2.443 1.006.58.652.88 1.494.88 2.523zm-1.59.05c0-.636-.14-1.18-.42-1.636-.32-.55-.78-.825-1.37-.825-.62 0-1.09.275-1.41.825-.276.455-.41 1.01-.41 1.664 0 .636.14 1.18.41 1.636.33.55.793.824 1.39.824.584 0 1.042-.28 1.372-.84.28-.462.42-1.012.42-1.648zm9 3.454h-1.37l-.12-.795h-.04c-.47.633-1.14.95-2.02.95-.65 0-1.178-.21-1.57-.624-.36-.37-.54-.84-.54-1.4 0-.84.36-1.48 1.06-1.93.71-.44 1.7-.66 2.98-.65v-.13c0-.9-.48-1.36-1.43-1.36-.68 0-1.28.17-1.8.51l-.31-1c.64-.39 1.43-.59 2.36-.59 1.8 0 2.7.95 2.7 2.85V18c0 .686.03 1.235.1 1.64zm-1.59-2.37v-1.06c-1.69-.03-2.54.434-2.54 1.39 0 .358.09.627.29.807.19.18.45.27.75.27.33 0 .65-.108.94-.32.28-.213.46-.483.53-.815.01-.075.02-.166.02-.27zm10.29 2.37h-1.36l-.07-1.108h-.04c-.437.842-1.177 1.264-2.21 1.264-.83 0-1.53-.326-2.07-.98-.55-.65-.83-1.497-.83-2.537 0-1.12.3-2.02.895-2.71.58-.65 1.287-.97 2.13-.97.924 0 1.57.31 1.94.93h.03V9.58h1.53v8.197c0 .67.02 1.29.06 1.857zM126 16.733v-1.15c0-.198-.013-.36-.04-.482-.08-.36-.27-.67-.55-.92s-.63-.37-1.02-.37c-.57 0-1.02.23-1.35.68-.325.46-.49 1.04-.49 1.75 0 .68.156 1.24.47 1.66.33.46.78.68 1.34.68.5 0 .905-.19 1.21-.57.296-.35.44-.77.44-1.26zm14.693-.597c0 1.06-.304 1.93-.91 2.61-.633.7-1.473 1.05-2.524 1.05-1.01 0-1.82-.335-2.42-1.008-.6-.67-.9-1.517-.9-2.538 0-1.067.31-1.943.93-2.623.62-.68 1.45-1.02 2.5-1.02 1.01 0 1.82.335 2.44 1.006.58.652.88 1.494.88 2.523zm-1.59.05c0-.636-.136-1.18-.41-1.636-.323-.55-.78-.825-1.375-.825-.61 0-1.08.275-1.4.825-.27.455-.41 1.01-.41 1.664 0 .636.14 1.18.41 1.636.33.55.798.824 1.39.824.59 0 1.05-.28 1.38-.84.28-.462.425-1.012.425-1.648zm9.827 3.454h-1.53v-3.95c0-1.217-.462-1.825-1.39-1.825-.455 0-.822.167-1.106.502-.284.333-.425.728-.425 1.18v4.088h-1.53v-4.92c0-.607-.02-1.263-.06-1.974h1.34l.07 1.08h.04c.18-.33.44-.61.79-.83.41-.25.88-.39 1.39-.39.64 0 1.17.21 1.6.63.53.51.79 1.27.79 2.29v4.13zm10.312-5.745h-1.688v3.348c0 .85.3 1.276.892 1.276.28 0 .51-.03.69-.08l.04 1.16c-.303.11-.7.17-1.19.17-.606 0-1.077-.19-1.417-.56-.35-.37-.51-.99-.51-1.86v-3.47h-1.01v-1.14h1v-1.26l1.5-.46v1.71h1.69v1.15zm8.11 5.745h-1.534v-3.92c0-1.234-.46-1.853-1.384-1.853-.71 0-1.196.358-1.462 1.075-.048.15-.075.334-.075.55v4.146h-1.53V9.585h1.53v4.153h.03c.49-.755 1.18-1.133 2.07-1.133.64 0 1.16.208 1.58.625.52.52.78 1.29.78 2.31v4.1zm8.367-3.773c0 .275-.02.506-.06.695h-4.6c.03.68.24 1.2.67 1.56.39.32.89.482 1.51.482.68 0 1.3-.108 1.86-.326l.24 1.064c-.66.284-1.43.426-2.32.426-1.07 0-1.91-.315-2.52-.943-.61-.63-.91-1.472-.91-2.53 0-1.04.28-1.906.85-2.596.59-.74 1.39-1.11 2.41-1.11.99 0 1.74.37 2.25 1.1.41.58.61 1.3.61 2.16zm-1.46-.396c.02-.45-.08-.84-.29-1.17-.27-.42-.67-.64-1.22-.64-.5 0-.91.21-1.22.63-.26.33-.41.73-.46 1.19h3.19z" fill="#FFF"/></g></svg> </a> </div> <div class="t391__btn t-animate" data-animate-style="zoomin" data-animate-group="yes" data-animate-order="4" data-animate-delay="0.2"> <a href="https://play.google.com/store/apps/details?id=com.Inanomo.PaganGods&hl=EN" target="_blank"> 
<svg role="presentation" viewBox="0 0 189 56" height="48px"><defs><lineargradient x1="91.545%" y1="4.836%" x2="-37.548%" y2="71.964%" id="a348944188"><stop stop-color="#00A0FF" offset="0%"/><stop stop-color="#00A1FF" offset=".657%"/><stop stop-color="#00BEFF" offset="26.01%"/><stop stop-color="#00D2FF" offset="51.22%"/><stop stop-color="#00DFFF" offset="76.04%"/><stop stop-color="#00E3FF" offset="100%"/></lineargradient><lineargradient x1="107.719%" y1="49.424%" x2="-130.664%" y2="49.424%" id="b348944188"><stop stop-color="#FFE000" offset="0%"/><stop stop-color="#FFBD00" offset="40.87%"/><stop stop-color="#FFA500" offset="77.54%"/><stop stop-color="#FF9C00" offset="100%"/></lineargradient><lineargradient x1="86.396%" y1="17.806%" x2="-49.883%" y2="194.385%" id="c348944188"><stop stop-color="#FF3A44" offset="0%"/><stop stop-color="#C31162" offset="100%"/></lineargradient><lineargradient x1="-18.578%" y1="-54.522%" x2="42.274%" y2="24.693%" id="d348944188"><stop stop-color="#32A071" offset="0%"/><stop stop-color="#2DA771" offset="6.85%"/><stop stop-color="#15CF74" offset="47.62%"/><stop stop-color="#06E775" offset="80.09%"/><stop stop-color="#00F076" offset="100%"/></lineargradient></defs><g fill="none" fill-rule="evenodd"><path d="M7 56c-3.92 0-7-3.08-7-7V7c0-3.92 3.08-7 7-7h175c3.92 0 7 3.08 7 7v42c0 3.92-3.08 7-7 7H7z" fill="#000"/><path d="M66.36 14.28c0 1.12-.28 2.1-.98 2.8-.84.84-1.82 1.26-3.08 1.26s-2.24-.42-3.08-1.26c-.84-.84-1.26-1.82-1.26-3.08s.42-2.24 1.26-3.08c.84-.84 1.82-1.26 3.08-1.26.56 0 1.12.14 1.68.42.56.28.98.56 1.26.98l-.7.7c-.56-.7-1.26-.98-2.24-.98-.84 0-1.68.28-2.24.98-.56.7-.98 1.4-.98 2.38s.28 1.82.98 2.38c.7.56 1.4.98 2.24.98.98 0 1.68-.28 2.38-.98.42-.42.7-.98.7-1.68H62.3v-.98h4.06v.42zm6.44-3.5h-3.78v2.66h3.5v.98h-3.5v2.66h3.78v1.12h-4.9V9.8h4.9v.98zm4.62 7.42H76.3v-7.42h-2.38V9.8h5.88v.98h-2.38v7.42zm6.44 0V9.8h1.12v8.4h-1.12zm5.88 0h-1.12v-7.42h-2.38V9.8h5.74v.98H89.6v7.42h.14zm13.3-1.12c-.84.84-1.82 1.26-3.08 1.26s-2.24-.42-3.08-1.26c-.84-.84-1.26-1.82-1.26-3.08s.42-2.24 1.26-3.08c.84-.84 1.82-1.26 3.08-1.26s2.24.42 3.08 1.26c.84.84 1.26 1.82 1.26 3.08s-.42 2.24-1.26 3.08zm-5.32-.7c.56.56 1.4.98 2.24.98.84 0 1.68-.28 2.24-.98.56-.56.98-1.4.98-2.38s-.28-1.82-.98-2.38c-.56-.56-1.4-.98-2.24-.98-.84 0-1.68.28-2.24.98-.56.56-.98 1.4-.98 2.38s.28 1.82.98 2.38zm8.12 1.82V9.8h1.26l4.06 6.58V9.8h1.12v8.4h-1.12l-4.34-6.86v6.86h-.98z" stroke="#FFF" stroke-width=".2" fill="#FFF"/><path d="M95.34 30.52c-3.36 0-6.02 2.52-6.02 6.02 0 3.36 2.66 6.02 6.02 6.02 3.36 0 6.02-2.52 6.02-6.02 0-3.64-2.66-6.02-6.02-6.02zm0 9.52c-1.82 0-3.36-1.54-3.36-3.64s1.54-3.64 3.36-3.64c1.82 0 3.36 1.4 3.36 3.64 0 2.1-1.54 3.64-3.36 3.64zm-13.02-9.52c-3.36 0-6.02 2.52-6.02 6.02 0 3.36 2.66 6.02 6.02 6.02 3.36 0 6.02-2.52 6.02-6.02 0-3.64-2.66-6.02-6.02-6.02zm0 9.52c-1.82 0-3.36-1.54-3.36-3.64s1.54-3.64 3.36-3.64c1.82 0 3.36 1.4 3.36 3.64 0 2.1-1.54 3.64-3.36 3.64zm-15.54-7.7v2.52h6.02c-.14 1.4-.7 2.52-1.4 3.22-.84.84-2.24 1.82-4.62 1.82-3.78 0-6.58-2.94-6.58-6.72s2.94-6.72 6.58-6.72c1.96 0 3.5.84 4.62 1.82l1.82-1.82c-1.54-1.4-3.5-2.52-6.3-2.52-5.04 0-9.38 4.2-9.38 9.24s4.34 9.24 9.38 9.24c2.8 0 4.76-.84 6.44-2.66 1.68-1.68 2.24-4.06 2.24-5.88 0-.56 0-1.12-.14-1.54h-8.68zm63.56 1.96c-.56-1.4-1.96-3.78-5.04-3.78s-5.6 2.38-5.6 6.02c0 3.36 2.52 6.02 5.88 6.02 2.66 0 4.34-1.68 4.9-2.66l-2.1-1.4c-.7.98-1.54 1.68-2.94 1.68s-2.24-.56-2.94-1.82l7.98-3.36-.14-.7zm-8.12 1.96c0-2.24 1.82-3.5 3.08-3.5.98 0 1.96.56 2.24 1.26l-5.32 2.24zM115.64 42h2.66V24.5h-2.66V42zm-4.2-10.22c-.7-.7-1.82-1.4-3.22-1.4-2.94 0-5.74 2.66-5.74 6.02 0 3.36 2.66 5.88 5.74 5.88 1.4 0 2.52-.7 3.08-1.4h.14v.84c0 2.24-1.26 3.5-3.22 3.5-1.54 0-2.66-1.12-2.94-2.1l-2.24.98c.7 1.54 2.38 3.5 5.32 3.5 3.08 0 5.6-1.82 5.6-6.16V30.8h-2.52v.98zm-3.08 8.26c-1.82 0-3.36-1.54-3.36-3.64s1.54-3.64 3.36-3.64c1.82 0 3.22 1.54 3.22 3.64s-1.4 3.64-3.22 3.64zm34.16-15.54h-6.3V42h2.66v-6.58h3.64c2.94 0 5.74-2.1 5.74-5.46s-2.8-5.46-5.74-5.46zm.14 8.4h-3.78v-6.02h3.78c1.96 0 3.08 1.68 3.08 2.94-.14 1.54-1.26 3.08-3.08 3.08zm16.1-2.52c-1.96 0-3.92.84-4.62 2.66l2.38.98c.56-.98 1.4-1.26 2.38-1.26 1.4 0 2.66.84 2.8 2.24v.14c-.42-.28-1.54-.7-2.66-.7-2.52 0-5.04 1.4-5.04 3.92 0 2.38 2.1 3.92 4.34 3.92 1.82 0 2.66-.84 3.36-1.68h.14V42h2.52v-6.72c-.28-3.08-2.66-4.9-5.6-4.9zm-.28 9.66c-.84 0-2.1-.42-2.1-1.54 0-1.4 1.54-1.82 2.8-1.82 1.12 0 1.68.28 2.38.56-.28 1.68-1.68 2.8-3.08 2.8zm14.7-9.24l-2.94 7.56h-.14l-3.08-7.56h-2.8l4.62 10.64-2.66 5.88h2.66l7.14-16.52h-2.8zM149.66 42h2.66V24.5h-2.66V42z" fill="#FFF"/><path d="M14.56 10.5c-.42.42-.7 1.12-.7 1.96V43.4c0 .84.28 1.54.7 1.96l.14.14 17.36-17.36v-.28L14.56 10.5z" fill="url(#a348944188)"/><path d="M37.8 34.02l-5.74-5.74v-.42l5.74-5.74.14.14 6.86 3.92c1.96 1.12 1.96 2.94 0 4.06l-7 3.78z" fill="url(#b348944188)"/><path d="M37.94 33.88L32.06 28l-17.5 17.5c.7.7 1.68.7 2.94.14l20.44-11.76" fill="url(#c348944188)"/><path d="M37.94 22.12L17.5 10.5c-1.26-.7-2.24-.56-2.94.14L32.06 28l5.88-5.88z" fill="url(#d348944188)"/><path d="M37.8 33.74L17.5 45.22c-1.12.7-2.1.56-2.8 0l-.14.14.14.14c.7.56 1.68.7 2.8 0l20.3-11.76z" opacity=".2" fill="#000"/><path d="M14.56 45.22c-.42-.42-.56-1.12-.56-1.96v.14c0 .84.28 1.54.7 1.96v-.14h-.14zm30.24-15.4l-7 3.92.14.14 6.86-3.92c.98-.56 1.4-1.26 1.4-1.96 0 .7-.56 1.26-1.4 1.82z" opacity=".12" fill="#000"/><path d="M17.5 10.64l27.3 15.54c.84.56 1.4 1.12 1.4 1.82 0-.7-.42-1.4-1.4-1.96L17.5 10.5c-1.96-1.12-3.5-.14-3.5 2.1v.14c0-2.24 1.54-3.22 3.5-2.1z" opacity=".25" fill="#FFF"/></g></svg> </a> </div> </div> </div> </div> </div> <div class="t391__secondcol t-col t-col_6 "> <div class="t-cover__wrapper t-valign_bottom" style="height: 70vh;"> <img src="images/12.png" imgfiled="img2" class="t391__img"> </div> </div> </div></div> </div> <script> t_onReady(function () {
t_onFuncLoad('t391_checkSize', function () {
t391_checkSize('348944188');
});
});
window.onload = function () {
t_onFuncLoad('t391_checkSize', function () {
t391_checkSize('348944188');
});
};
t_onFuncLoad('t391_checkSize', function () {
window.addEventListener('resize', t_throttle(function () {
t391_checkSize('348944188');
}));
});</script> </div><div id="rec315366461" class="r t-rec t-rec_pb_0" style="padding-bottom:0px;background-color:#171717; " data-record-type="396" data-bg-color="#171717"><!-- T396 --><style>#rec315366461 .t396__artboard{height: 826px;background-color: #171717;}#rec315366461 .t396__filter{height: 826px;}#rec315366461 .t396__carrier{height: 826px;background-position: left bottom;background-attachment: scroll;background-size:cover;background-repeat:no-repeat;}@media screen and (max-width: 1199px){#rec315366461 .t396__artboard{height: 745px;}#rec315366461 .t396__filter{height: 745px;}#rec315366461 .t396__carrier{height: 745px;background-attachment:scroll;}}@media screen and (max-width: 959px){#rec315366461 .t396__artboard{height: 1100px;}#rec315366461 .t396__filter{height: 1100px;}#rec315366461 .t396__carrier{height: 1100px;}}@media screen and (max-width: 639px){#rec315366461 .t396__artboard{height: 1010px;}#rec315366461 .t396__filter{height: 1010px;}#rec315366461 .t396__carrier{height: 1010px;}}@media screen and (max-width: 479px){#rec315366461 .t396__artboard{height: 1125px;background-color:#171717;}#rec315366461 .t396__filter{height: 1125px;}#rec315366461 .t396__carrier{height: 1125px;background-position: left bottom;}}#rec315366461 .tn-elem[data-elem-id="1480507359771"]{color:#ffffff;z-index:25;top: 103px;left: calc(50% - 600px + 20px);width:760px;}#rec315366461 .tn-elem[data-elem-id="1480507359771"] .tn-atom{color:#ffffff;font-size:52px;font-family:'Circe',Arial,sans-serif;line-height:1.55;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1480507359771"]{top: 75px;left: calc(50% - 480px + 60px);width:940px;}#rec315366461 .tn-elem[data-elem-id="1480507359771"] .tn-atom{font-size:38px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1480507359771"]{top: 80px;left: calc(50% - 320px + 100px);width:620px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1480507359771"]{top: 62px;left: calc(50% - 240px + 30px);width:360px;}#rec315366461 .tn-elem[data-elem-id="1480507359771"] .tn-atom{font-size:30px;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1480507359771"]{top: 30px;left: calc(50% - 160px + 20px);width:280px;}#rec315366461 .tn-elem[data-elem-id="1480507359771"]{text-align:center;}}#rec315366461 .tn-elem[data-elem-id="1620550718355"]{z-index:35;top: 191px;left: calc(50% - 600px + 676px);width:484px;}#rec315366461 .tn-elem[data-elem-id="1620550718355"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1620550718355"]{top: 105px;left: calc(50% - 480px + 510px);width:479px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1620550718355"]{top: 681px;left: calc(50% - 320px + 130px);width:390px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1620550718355"]{top: 590px;left: calc(50% - 240px + 30px);}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1620550718355"]{top: 665px;left: calc(50% - 160px + -40px);width:400px;}}#rec315366461 .tn-elem[data-elem-id="1620549410257"]{color:#171717;text-align:center;z-index:33;top: 545px;left: calc(50% - 600px + 28px);width:30px;}#rec315366461 .tn-elem[data-elem-id="1620549410257"] .tn-atom{color:#171717;font-size:24px;font-family:'Circe',Arial,sans-serif;line-height:1.55;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1620549410257"]{top: 509px;left: calc(50% - 480px + 67px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1620549410257"]{top: 537px;left: calc(50% - 320px + 101px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1620549410257"]{top: 447px;left: calc(50% - 240px + 32px);}#rec315366461 .tn-elem[data-elem-id="1620549410257"] .tn-atom{font-size:16px;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1620549410257"]{top: 506px;left: calc(50% - 160px + 21px);}}#rec315366461 .tn-elem[data-elem-id="1620549410247"]{z-index:32;top: 540px;left: calc(50% - 600px + 21px);width:44px;height:44px;}#rec315366461 .tn-elem[data-elem-id="1620549410247"] .tn-atom{border-width:0px;border-radius:3000px;background-color:#ffbb00;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1620549410247"]{top: 502px;left: calc(50% - 480px + 60px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1620549410247"]{top: 530px;left: calc(50% - 320px + 95px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1620549410247"]{top: 436px;left: calc(50% - 240px + 25px);}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1620549410247"]{top: 495px;left: calc(50% - 160px + 14px);}}#rec315366461 .tn-elem[data-elem-id="1620549410237"]{color:#ffffff;z-index:31;top: 546px;left: calc(50% - 600px + 91px);width:685px;}#rec315366461 .tn-elem[data-elem-id="1620549410237"] .tn-atom{color:#ffffff;font-size:22px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1620549410237"]{top: 496px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1620549410237"] .tn-atom{font-size:20px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1620549410237"]{top: 527px;left: calc(50% - 320px + 170px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1620549410237"]{top: 432px;left: calc(50% - 240px + 100px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1620549410237"] .tn-atom{font-size:18px;line-height:1.35;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1620549410237"]{top: 495px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1620549410237"]{text-align:left;}#rec315366461 .tn-elem[data-elem-id="1620549410237"] .tn-atom{line-height:1.25;}}#rec315366461 .tn-elem[data-elem-id="1620549410233"]{color:#ffffff;z-index:30;top: 581px;left: calc(50% - 600px + 91px);width:525px;}#rec315366461 .tn-elem[data-elem-id="1620549410233"] .tn-atom{color:#ffffff;font-size:15px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:400;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1620549410233"]{top: 528px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1620549410233"] .tn-atom{font-size:14px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1620549410233"]{top: 562px;left: calc(50% - 320px + 170px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1620549410233"]{top: 459px;left: calc(50% - 240px + 100px);width:270px;}#rec315366461 .tn-elem[data-elem-id="1620549410233"] .tn-atom{font-size:12px;line-height:1.45;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1620549410233"]{top: 524px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1620549410233"]{text-align:left;}}#rec315366461 .tn-elem[data-elem-id="1474637987992"]{color:#171717;text-align:center;z-index:29;top: 434px;left: calc(50% - 600px + 28px);width:30px;}#rec315366461 .tn-elem[data-elem-id="1474637987992"] .tn-atom{color:#171717;font-size:24px;font-family:'Circe',Arial,sans-serif;line-height:1.55;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474637987992"]{top: 405px;left: calc(50% - 480px + 67px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474637987992"]{top: 411px;left: calc(50% - 320px + 102px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474637987992"]{top: 353px;left: calc(50% - 240px + 32px);}#rec315366461 .tn-elem[data-elem-id="1474637987992"] .tn-atom{font-size:16px;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474637987992"]{top: 381px;left: calc(50% - 160px + 21px);}}#rec315366461 .tn-elem[data-elem-id="1474637985975"]{color:#171717;text-align:center;z-index:28;top: 340px;left: calc(50% - 600px + 28px);width:30px;}#rec315366461 .tn-elem[data-elem-id="1474637985975"] .tn-atom{color:#171717;font-size:24px;font-family:'Circe',Arial,sans-serif;line-height:1.55;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474637985975"]{top: 316px;left: calc(50% - 480px + 67px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474637985975"]{top: 312px;left: calc(50% - 320px + 102px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474637985975"]{top: 272px;left: calc(50% - 240px + 32px);}#rec315366461 .tn-elem[data-elem-id="1474637985975"] .tn-atom{font-size:16px;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474637985975"]{top: 290px;left: calc(50% - 160px + 21px);}}#rec315366461 .tn-elem[data-elem-id="1474637939938"]{color:#171717;text-align:center;z-index:26;top: 226px;left: calc(50% - 600px + 28px);width:30px;}#rec315366461 .tn-elem[data-elem-id="1474637939938"] .tn-atom{color:#171717;font-size:24px;font-family:'Circe',Arial,sans-serif;line-height:1.55;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474637939938"]{top: 208px;left: calc(50% - 480px + 67px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474637939938"]{top: 183px;left: calc(50% - 320px + 102px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474637939938"]{top: 161px;left: calc(50% - 240px + 32px);}#rec315366461 .tn-elem[data-elem-id="1474637939938"] .tn-atom{font-size:16px;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474637939938"]{top: 146px;left: calc(50% - 160px + 21px);}}#rec315366461 .tn-elem[data-elem-id="1474633107906"]{z-index:24;top: 429px;left: calc(50% - 600px + 21px);width:44px;height:44px;}#rec315366461 .tn-elem[data-elem-id="1474633107906"] .tn-atom{border-width:0px;border-radius:3000px;background-color:#ffbb00;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474633107906"]{top: 398px;left: calc(50% - 480px + 60px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474633107906"]{top: 404px;left: calc(50% - 320px + 95px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474633107906"]{top: 342px;left: calc(50% - 240px + 25px);}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474633107906"]{top: 371px;left: calc(50% - 160px + 14px);}}#rec315366461 .tn-elem[data-elem-id="1474627416586"]{z-index:23;top: 221px;left: calc(50% - 600px + 21px);width:44px;height:44px;}#rec315366461 .tn-elem[data-elem-id="1474627416586"] .tn-atom{border-width:0px;border-radius:3000px;background-color:#ffbb00;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474627416586"]{top: 201px;left: calc(50% - 480px + 60px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474627416586"]{top: 176px;left: calc(50% - 320px + 95px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474627416586"]{top: 150px;left: calc(50% - 240px + 25px);}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474627416586"]{top: 136px;left: calc(50% - 160px + 14px);}}#rec315366461 .tn-elem[data-elem-id="1474633099333"]{z-index:22;top: 335px;left: calc(50% - 600px + 21px);width:44px;height:44px;}#rec315366461 .tn-elem[data-elem-id="1474633099333"] .tn-atom{border-width:0px;border-radius:3000px;background-color:#ffbb00;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474633099333"]{top: 309px;left: calc(50% - 480px + 60px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474633099333"]{top: 305px;left: calc(50% - 320px + 95px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474633099333"]{top: 261px;left: calc(50% - 240px + 25px);}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474633099333"]{top: 280px;left: calc(50% - 160px + 14px);height:44px;}}#rec315366461 .tn-elem[data-elem-id="1474628077848"]{color:#ffffff;z-index:21;top: 435px;left: calc(50% - 600px + 91px);width:685px;}#rec315366461 .tn-elem[data-elem-id="1474628077848"] .tn-atom{color:#ffffff;font-size:22px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474628077848"]{top: 393px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1474628077848"] .tn-atom{font-size:20px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474628077848"]{top: 400px;left: calc(50% - 320px + 171px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474628077848"]{top: 341px;left: calc(50% - 240px + 100px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1474628077848"] .tn-atom{font-size:18px;line-height:1.35;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474628077848"]{top: 369px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1474628077848"]{text-align:left;}}#rec315366461 .tn-elem[data-elem-id="1474628075709"]{color:#ffffff;z-index:20;top: 470px;left: calc(50% - 600px + 91px);width:585px;}#rec315366461 .tn-elem[data-elem-id="1474628075709"] .tn-atom{color:#ffffff;font-size:15px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:400;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474628075709"]{top: 424px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1474628075709"] .tn-atom{font-size:14px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474628075709"]{top: 435px;left: calc(50% - 320px + 171px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474628075709"]{top: 368px;left: calc(50% - 240px + 100px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1474628075709"] .tn-atom{font-size:12px;line-height:1.45;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474628075709"]{top: 397px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1474628075709"]{text-align:left;}}#rec315366461 .tn-elem[data-elem-id="1474627943918"]{color:#ffffff;z-index:19;top: 227px;left: calc(50% - 600px + 91px);width:685px;}#rec315366461 .tn-elem[data-elem-id="1474627943918"] .tn-atom{color:#ffffff;font-size:22px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474627943918"]{top: 197px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1474627943918"] .tn-atom{font-size:20px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474627943918"]{top: 172px;left: calc(50% - 320px + 171px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474627943918"]{top: 149px;left: calc(50% - 240px + 100px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1474627943918"] .tn-atom{font-size:18px;line-height:1.35;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474627943918"]{top: 134px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1474627943918"]{text-align:left;}}#rec315366461 .tn-elem[data-elem-id="1474627941995"]{color:#ffffff;z-index:18;top: 262px;left: calc(50% - 600px + 91px);width:525px;}#rec315366461 .tn-elem[data-elem-id="1474627941995"] .tn-atom{color:#ffffff;font-size:15px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:400;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474627941995"]{top: 230px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1474627941995"] .tn-atom{font-size:14px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474627941995"]{top: 207px;left: calc(50% - 320px + 171px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474627941995"]{top: 176px;left: calc(50% - 240px + 100px);width:340px;}#rec315366461 .tn-elem[data-elem-id="1474627941995"] .tn-atom{font-size:12px;line-height:1.45;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474627941995"]{top: 162px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1474627941995"]{text-align:left;}}#rec315366461 .tn-elem[data-elem-id="1474627361375"]{color:#ffffff;z-index:17;top: 373px;left: calc(50% - 600px + 91px);width:525px;}#rec315366461 .tn-elem[data-elem-id="1474627361375"] .tn-atom{color:#ffffff;font-size:15px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:400;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474627361375"]{top: 338px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1474627361375"] .tn-atom{font-size:14px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474627361375"]{top: 334px;left: calc(50% - 320px + 171px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474627361375"]{top: 285px;left: calc(50% - 240px + 100px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1474627361375"] .tn-atom{font-size:12px;line-height:1.45;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474627361375"]{top: 306px;left: calc(50% - 160px + 80px);width:220px;}}#rec315366461 .tn-elem[data-elem-id="1470210011265"]{color:#ffffff;z-index:16;top: 337px;left: calc(50% - 600px + 91px);width:685px;}#rec315366461 .tn-elem[data-elem-id="1470210011265"] .tn-atom{color:#ffffff;font-size:22px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1470210011265"]{top: 305px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1470210011265"] .tn-atom{font-size:20px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1470210011265"]{top: 302px;left: calc(50% - 320px + 171px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1470210011265"] .tn-atom{line-height:1.4;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1470210011265"]{top: 258px;left: calc(50% - 240px + 100px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1470210011265"] .tn-atom{font-size:18px;line-height:1.35;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1470210011265"]{top: 278px;left: calc(50% - 160px + 80px);width:220px;}}#rec315366461 .tn-elem[data-elem-id="1474627468992"]{z-index:15;top: 241px;left: calc(50% - 600px + 42px);width:2px;height:420px;}#rec315366461 .tn-elem[data-elem-id="1474627468992"] .tn-atom{opacity:0.2;background-color:#e8e8e8;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1474627468992"]{top: 212px;left: calc(50% - 480px + 81px);height:400px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1474627468992"]{top: 211px;left: calc(50% - 320px + 116px);height:480px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1474627468992"]{top: 176px;left: calc(50% - 240px + 46px);height:410px;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1474627468992"]{top: 176px;left: calc(50% - 160px + 35px);height:480px;}}#rec315366461 .tn-elem[data-elem-id="1643978194380"]{color:#ffffff;z-index:36;top: 691px;left: calc(50% - 600px + 90px);width:525px;}#rec315366461 .tn-elem[data-elem-id="1643978194380"] .tn-atom{color:#ffffff;font-size:15px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:400;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1643978194380"]{top: 632px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1643978194380"] .tn-atom{font-size:14px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1643978194380"]{top: 682px;left: calc(50% - 320px + 169px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1643978194380"]{top: 575px;left: calc(50% - 240px + 100px);width:270px;}#rec315366461 .tn-elem[data-elem-id="1643978194380"] .tn-atom{font-size:12px;line-height:1.45;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1643978194380"]{top: 649px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1643978194380"]{text-align:left;}}#rec315366461 .tn-elem[data-elem-id="1643978194454"]{color:#ffffff;z-index:37;top: 656px;left: calc(50% - 600px + 91px);width:685px;}#rec315366461 .tn-elem[data-elem-id="1643978194454"] .tn-atom{color:#ffffff;font-size:22px;font-family:'Circe',Arial,sans-serif;line-height:1.4;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1643978194454"]{top: 603px;left: calc(50% - 480px + 130px);width:550px;}#rec315366461 .tn-elem[data-elem-id="1643978194454"] .tn-atom{font-size:20px;}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1643978194454"]{top: 647px;left: calc(50% - 320px + 169px);width:380px;}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1643978194454"]{top: 549px;left: calc(50% - 240px + 100px);width:380px;}#rec315366461 .tn-elem[data-elem-id="1643978194454"] .tn-atom{font-size:18px;line-height:1.35;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1643978194454"]{top: 620px;left: calc(50% - 160px + 80px);width:220px;}#rec315366461 .tn-elem[data-elem-id="1643978194454"]{text-align:left;}}#rec315366461 .tn-elem[data-elem-id="1643978194516"]{z-index:38;top: 651px;left: calc(50% - 600px + 21px);width:44px;height:44px;}#rec315366461 .tn-elem[data-elem-id="1643978194516"] .tn-atom{border-width:0px;border-radius:3000px;background-color:#ffbb00;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1643978194516"]{top: 600px;left: calc(50% - 480px + 60px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1643978194516"]{top: 651px;left: calc(50% - 320px + 94px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1643978194516"]{top: 553px;left: calc(50% - 240px + 25px);}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1643978194516"]{top: 619px;left: calc(50% - 160px + 14px);}}#rec315366461 .tn-elem[data-elem-id="1643978194565"]{color:#171717;text-align:center;z-index:39;top: 657px;left: calc(50% - 600px + 28px);width:30px;}#rec315366461 .tn-elem[data-elem-id="1643978194565"] .tn-atom{color:#171717;font-size:24px;font-family:'Circe',Arial,sans-serif;line-height:1.55;font-weight:700;background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){#rec315366461 .tn-elem[data-elem-id="1643978194565"]{top: 607px;left: calc(50% - 480px + 67px);}}@media screen and (max-width: 959px){#rec315366461 .tn-elem[data-elem-id="1643978194565"]{top: 658px;left: calc(50% - 320px + 100px);}}@media screen and (max-width: 639px){#rec315366461 .tn-elem[data-elem-id="1643978194565"]{top: 563px;left: calc(50% - 240px + 32px);}#rec315366461 .tn-elem[data-elem-id="1643978194565"] .tn-atom{font-size:16px;}}@media screen and (max-width: 479px){#rec315366461 .tn-elem[data-elem-id="1643978194565"]{top: 630px;left: calc(50% - 160px + 21px);}}</style> 
<div class="t396"><div class="t396__artboard" data-artboard-recid="315366461" data-artboard-height="826" data-artboard-height-res-960="745" data-artboard-height-res-640="1100" data-artboard-height-res-480="1010" data-artboard-height-res-320="1125" data-artboard-height_vh data-artboard-valign="center" data-artboard-upscale="grid" data-artboard-upscale-res-320="grid" data-artboard-ovrflw> <div class="t396__carrier" data-artboard-recid="315366461"></div> 
<div class="t396__filter" data-artboard-recid="315366461"></div> 
<div class="t396__elem tn-elem tn-elem__3153664611480507359771 t-animate" data-elem-id="1480507359771" data-elem-type="text" data-field-top-value="103" data-field-top-res-960-value="75" data-field-top-res-640-value="80" data-field-top-res-480-value="62" data-field-top-res-320-value="30" data-field-left-value="20" data-field-left-res-960-value="60" data-field-left-res-640-value="100" data-field-left-res-480-value="30" data-field-left-res-320-value="20" data-field-width-value="760" data-field-width-res-960-value="940" data-field-width-res-640-value="620" data-field-width-res-480-value="360" data-field-width-res-320-value="280" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-style="fadeinright" data-animate-duration="1" data-animate-distance="100"> 
<div class="tn-atom" field="tn_text_1480507359771"><strong></strong>Roadmap</div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611620550718355 t-animate" data-elem-id="1620550718355" data-elem-type="image" data-field-top-value="191" data-field-top-res-960-value="105" data-field-top-res-640-value="681" data-field-top-res-480-value="590" data-field-top-res-320-value="665" data-field-left-value="676" data-field-left-res-960-value="510" data-field-left-res-640-value="130" data-field-left-res-480-value="30" data-field-left-res-320-value="-40" data-field-width-value="484" data-field-width-res-960-value="479" data-field-width-res-640-value="390" data-field-width-res-320-value="400" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-style="zoomin" data-animate-duration="1" data-animate-scale="0.9"> 
<div class="tn-atom"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild6563-3564-4232-b463-383130626539/_1_1.png" imgfield="tn_img_1620550718355"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611620549410257" data-elem-id="1620549410257" data-elem-type="text" data-field-top-value="545" data-field-top-res-960-value="509" data-field-top-res-640-value="537" data-field-top-res-480-value="447" data-field-top-res-320-value="506" data-field-left-value="28" data-field-left-res-960-value="67" data-field-left-res-640-value="101" data-field-left-res-480-value="32" data-field-left-res-320-value="21" data-field-width-value="30" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1620549410257">4</div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611620549410247" data-elem-id="1620549410247" data-elem-type="shape" data-field-top-value="540" data-field-top-res-960-value="502" data-field-top-res-640-value="530" data-field-top-res-480-value="436" data-field-top-res-320-value="495" data-field-left-value="21" data-field-left-res-960-value="60" data-field-left-res-640-value="95" data-field-left-res-480-value="25" data-field-left-res-320-value="14" data-field-height-value="44" data-field-width-value="44" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"> 
<div class="tn-atom"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611620549410237" data-elem-id="1620549410237" data-elem-type="text" data-field-top-value="546" data-field-top-res-960-value="496" data-field-top-res-640-value="527" data-field-top-res-480-value="432" data-field-top-res-320-value="495" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="170" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="685" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="380" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1620549410237"><strong>Q1 2022</strong><br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611620549410233" data-elem-id="1620549410233" data-elem-type="text" data-field-top-value="581" data-field-top-res-960-value="528" data-field-top-res-640-value="562" data-field-top-res-480-value="459" data-field-top-res-320-value="524" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="170" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="525" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="270" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1620549410233">New PvE-mode: rating system for players. Full-fledged mobile app launch.<br>Adding marketplace to the app</div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474637987992" data-elem-id="1474637987992" data-elem-type="text" data-field-top-value="434" data-field-top-res-960-value="405" data-field-top-res-640-value="411" data-field-top-res-480-value="353" data-field-top-res-320-value="381" data-field-left-value="28" data-field-left-res-960-value="67" data-field-left-res-640-value="102" data-field-left-res-480-value="32" data-field-left-res-320-value="21" data-field-width-value="30" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474637987992">3</div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474637985975" data-elem-id="1474637985975" data-elem-type="text" data-field-top-value="340" data-field-top-res-960-value="316" data-field-top-res-640-value="312" data-field-top-res-480-value="272" data-field-top-res-320-value="290" data-field-left-value="28" data-field-left-res-960-value="67" data-field-left-res-640-value="102" data-field-left-res-480-value="32" data-field-left-res-320-value="21" data-field-width-value="30" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474637985975">2</div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474637939938" data-elem-id="1474637939938" data-elem-type="text" data-field-top-value="226" data-field-top-res-960-value="208" data-field-top-res-640-value="183" data-field-top-res-480-value="161" data-field-top-res-320-value="146" data-field-left-value="28" data-field-left-res-960-value="67" data-field-left-res-640-value="102" data-field-left-res-480-value="32" data-field-left-res-320-value="21" data-field-width-value="30" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474637939938">1</div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474633107906" data-elem-id="1474633107906" data-elem-type="shape" data-field-top-value="429" data-field-top-res-960-value="398" data-field-top-res-640-value="404" data-field-top-res-480-value="342" data-field-top-res-320-value="371" data-field-left-value="21" data-field-left-res-960-value="60" data-field-left-res-640-value="95" data-field-left-res-480-value="25" data-field-left-res-320-value="14" data-field-height-value="44" data-field-width-value="44" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"> 
<div class="tn-atom"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474627416586" data-elem-id="1474627416586" data-elem-type="shape" data-field-top-value="221" data-field-top-res-960-value="201" data-field-top-res-640-value="176" data-field-top-res-480-value="150" data-field-top-res-320-value="136" data-field-left-value="21" data-field-left-res-960-value="60" data-field-left-res-640-value="95" data-field-left-res-480-value="25" data-field-left-res-320-value="14" data-field-height-value="44" data-field-width-value="44" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"> 
<div class="tn-atom"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474633099333" data-elem-id="1474633099333" data-elem-type="shape" data-field-top-value="335" data-field-top-res-960-value="309" data-field-top-res-640-value="305" data-field-top-res-480-value="261" data-field-top-res-320-value="280" data-field-left-value="21" data-field-left-res-960-value="60" data-field-left-res-640-value="95" data-field-left-res-480-value="25" data-field-left-res-320-value="14" data-field-height-value="44" data-field-height-res-320-value="44" data-field-width-value="44" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"> 
<div class="tn-atom"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474628077848" data-elem-id="1474628077848" data-elem-type="text" data-field-top-value="435" data-field-top-res-960-value="393" data-field-top-res-640-value="400" data-field-top-res-480-value="341" data-field-top-res-320-value="369" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="171" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="685" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="380" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474628077848"><strong> Q4 2021</strong><br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474628075709" data-elem-id="1474628075709" data-elem-type="text" data-field-top-value="470" data-field-top-res-960-value="424" data-field-top-res-640-value="435" data-field-top-res-480-value="368" data-field-top-res-320-value="397" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="171" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="585" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="380" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474628075709">Adding new characters and items. <br>Development the Economy 2.0 and PvP-mode<br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474627943918" data-elem-id="1474627943918" data-elem-type="text" data-field-top-value="227" data-field-top-res-960-value="197" data-field-top-res-640-value="172" data-field-top-res-480-value="149" data-field-top-res-320-value="134" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="171" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="685" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="380" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474627943918"><strong> June 2021</strong></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474627941995" data-elem-id="1474627941995" data-elem-type="text" data-field-top-value="262" data-field-top-res-960-value="230" data-field-top-res-640-value="207" data-field-top-res-480-value="176" data-field-top-res-320-value="162" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="171" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="525" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="340" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474627941995">Finalization of the game world concept. Further development of the mechanics. <br>Required renderings of NFT cards and sale of unique packs <br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474627361375" data-elem-id="1474627361375" data-elem-type="text" data-field-top-value="373" data-field-top-res-960-value="338" data-field-top-res-640-value="334" data-field-top-res-480-value="285" data-field-top-res-320-value="306" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="171" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="525" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="380" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1474627361375">PvE mode launch (final version)<br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611470210011265" data-elem-id="1470210011265" data-elem-type="text" data-field-top-value="337" data-field-top-res-960-value="305" data-field-top-res-640-value="302" data-field-top-res-480-value="258" data-field-top-res-320-value="278" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="171" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="685" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="380" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1470210011265"><strong> August 2021</strong><br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611474627468992" data-elem-id="1474627468992" data-elem-type="shape" data-field-top-value="241" data-field-top-res-960-value="212" data-field-top-res-640-value="211" data-field-top-res-480-value="176" data-field-top-res-320-value="176" data-field-left-value="42" data-field-left-res-960-value="81" data-field-left-res-640-value="116" data-field-left-res-480-value="46" data-field-left-res-320-value="35" data-field-height-value="420" data-field-height-res-960-value="400" data-field-height-res-640-value="480" data-field-height-res-480-value="410" data-field-height-res-320-value="480" data-field-width-value="2" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"> 
<div class="tn-atom"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611643978194380" data-elem-id="1643978194380" data-elem-type="text" data-field-top-value="691" data-field-top-res-960-value="632" data-field-top-res-640-value="682" data-field-top-res-480-value="575" data-field-top-res-320-value="649" data-field-left-value="90" data-field-left-res-960-value="130" data-field-left-res-640-value="169" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="525" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="270" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1643978194380">PvP-mode. Buildings and defensive structures. Development of the 3D version of the game<br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611643978194454" data-elem-id="1643978194454" data-elem-type="text" data-field-top-value="656" data-field-top-res-960-value="603" data-field-top-res-640-value="647" data-field-top-res-480-value="549" data-field-top-res-320-value="620" data-field-left-value="91" data-field-left-res-960-value="130" data-field-left-res-640-value="169" data-field-left-res-480-value="100" data-field-left-res-320-value="80" data-field-width-value="685" data-field-width-res-960-value="550" data-field-width-res-640-value="380" data-field-width-res-480-value="380" data-field-width-res-320-value="220" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1643978194454"><strong>Q2 2022</strong><br></div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611643978194516" data-elem-id="1643978194516" data-elem-type="shape" data-field-top-value="651" data-field-top-res-960-value="600" data-field-top-res-640-value="651" data-field-top-res-480-value="553" data-field-top-res-320-value="619" data-field-left-value="21" data-field-left-res-960-value="60" data-field-left-res-640-value="94" data-field-left-res-480-value="25" data-field-left-res-320-value="14" data-field-height-value="44" data-field-width-value="44" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value="px" data-field-widthunits-value="px"> 
<div class="tn-atom"> </div> 
</div> 
<div class="t396__elem tn-elem tn-elem__3153664611643978194565" data-elem-id="1643978194565" data-elem-type="text" data-field-top-value="657" data-field-top-res-960-value="607" data-field-top-res-640-value="658" data-field-top-res-480-value="563" data-field-top-res-320-value="630" data-field-left-value="28" data-field-left-res-960-value="67" data-field-left-res-640-value="100" data-field-left-res-480-value="32" data-field-left-res-320-value="21" data-field-width-value="30" data-field-axisy-value="top" data-field-axisx-value="left" data-field-container-value="grid" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px"> 
<div class="tn-atom" field="tn_text_1643978194565">5</div> 
</div> 
</div> </div> <script>$( document ).ready(function() { 
t396_init('315366461'); 
});</script><!-- /T396 --></div><div  id="rec410137371" class="r t-rec t-rec_pt_0 t-rec_pb_0 t-screenmin-480px" style="padding-top:0px;padding-bottom:0px;background-color:#171717; " data-animationappear="off" data-record-type="897" data-screen-min="480px" data-bg-color="#171717"><!-- t897 --><div class="t897"><div class="t-section__container t-container"><div class="t-col t-col_12"><div class="t-section__topwrapper t-align_left"><div class="t-section__title t-title t-title_xs" field="btitle"><div style="font-size:52px;font-family:&#x27;Circe&#x27;;color:#ffffff;" data-customstyle="yes"><strong>Our news</strong></div></div></div></div></div><!-- grid container start --><div class="js-feed t-feed t-feed_col" data-feed-grid-type="col" data-feed-recid="410137371"> <div class="t-feed__container t897__container"> <div class="js-feed-parts-select-container t-col t-col_12"></div> </div> <!-- preloader els --> <div class="js-feed-preloader t-feed__post-preloader_col t-feed__post-preloader__container_hidden t897__container t897__container_mobile-flex"> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-clear t-feed__grid-separator"></div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> </div> <!-- preloader els end --> 
<div class="t897__scroll-icon-wrapper" style="mix-blend-mode: lighten;"> <!--?xml version="1.0" encoding="UTF-8"?--> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 300" height="42" width="42"> <rect class="tooltip-horizontal-scroll-icon_card" x="480" width="200" height="200" rx="5" fill="rgba(255,255,255,0.2)"/> <rect class="tooltip-horizontal-scroll-icon_card" y="0" width="200" height="200" rx="5" fill="rgba(255,255,255,0.2)"/> <rect class="tooltip-horizontal-scroll-icon_card" x="240" width="200" height="200" rx="5" fill="rgba(255,255,255,0.2)"/> <path class="tooltip-horizontal-scroll-icon_hand" d="M78.9579 285.7C78.9579 285.7 37.8579 212.5 20.5579 180.8C-2.44209 138.6 -6.2422 120.8 9.6579 112C19.5579 106.5 33.2579 108.8 41.6579 123.4L61.2579 154.6V32.3C61.2579 32.3 60.0579 0 83.0579 0C107.558 0 105.458 32.3 105.458 32.3V91.7C105.458 91.7 118.358 82.4 133.458 86.6C141.158 88.7 150.158 92.4 154.958 104.6C154.958 104.6 185.658 89.7 200.958 121.4C200.958 121.4 236.358 114.4 236.358 151.1C236.358 187.8 192.158 285.7 192.158 285.7H78.9579Z" fill="rgba(255,255,255,1)"/> <style> .tooltip-horizontal-scroll-icon_hand {
animation: tooltip-horizontal-scroll-icon_anim-scroll-hand 2s infinite
}
.tooltip-horizontal-scroll-icon_card {
animation: tooltip-horizontal-scroll-icon_anim-scroll-card 2s infinite
}
@keyframes tooltip-horizontal-scroll-icon_anim-scroll-hand {
0% { transform: translateX(80px) scale(1); opacity: 0 }
10% { transform: translateX(80px) scale(1); opacity: 1 }
20%,60% { transform: translateX(175px) scale(.6); opacity: 1 }
80% { transform: translateX(5px) scale(.6); opacity: 1 } to { transform: translateX(5px) scale(.6); opacity: 0 }
}
@keyframes tooltip-horizontal-scroll-icon_anim-scroll-card {
0%,60% { transform: translateX(0) }
80%,to { transform: translateX(-240px) }
}
</style> </svg></div> 
<div class="js-feed-container t-feed__container t897__container t897__container_mobile-flex" data-feed-show-count="3" data-feed-show-slice="1"></div></div><!-- grid container end --></div><style type="text/css"> /* Feed part switch buttons styles */
#rec410137371 .t-feed__parts-switch-btn {
font-weight:400;
border:1px solid #000000;
border-radius: 40px; }
#rec410137371 .t-feed__parts-switch-btn span,
#rec410137371 .t-feed__parts-switch-btn a {
color:#000000;
padding: 6px 18px 6px;
}
#rec410137371 .t-feed__parts-switch-btn.t-active {
background-color: #000000;
}
#rec410137371 .t-feed__parts-switch-btn.t-active span,
#rec410137371 .t-feed__parts-switch-btn.t-active a {
color:#ffffff !important; }</style> 
<style type="text/css"> #rec410137371 .t-feed__post-popup__cover-wrapper .t-slds__arrow {
background-color: rgba(255,255,255,1);
}
</style> <style type="text/css"> #rec410137371 .t-feed__post-popup__cover-wrapper .t-slds__bullet_active .t-slds__bullet_body,
#rec410137371 .t-feed__post-popup__cover-wrapper .t-slds__bullet:hover .t-slds__bullet_body {
background-color: #222 !important;
}</style><!-- news setup start --><script type="text/javascript">t_onReady(function(){
var typography_optsObj = {
title: "color:#ffffff;font-family:'Circe';",
descr: "color:#ffffff;font-family:'Circe';",
subtitle: "color:#ffffff;"
};
var separator_optsObj = {
height: '',
color: '',
opacity: '',
hideSeparator: false };
var popup_optsObj = {
popupBgColor: '#ffffff',
overlayBgColorRgba: 'rgba(255,255,255,1)',
closeText: '',
iconColor: '#000000',
popupStat: '',
titleColor: '',
textColor: '',
subtitleColor: '',
datePos: 'aftertext',
partsPos: 'aftertext',
imagePos: 'aftertitle',
inTwoColumns: false,
zoom: false,
styleRelevants: '',
methodRelevants: 'random',
titleRelevants: '',
showRelevants: 'cc',
shareStyle: '',
shareBg: '',
isShare: false,
shareServices: '',
shareFBToken: '',
showDate: true,
bgSize: 'contain'
};
var arrowtop_optsObj = {
isShow: false,
style: '',
color: '',
bottom: '',
left: '',
right: ''
};
var parts_optsObj = {
partsBgColor: '',
partsBorderSize: '1px',
partsBorderColor: '#000000',
align: 'left'
};
var gallery_optsObj = {
control: '',
arrowSize: '',
arrowBorderSize: '3',
arrowColor: '#ffffff',
arrowColorHover: '',
arrowBg: '#ffffff',
arrowBgHover: '',
arrowBgOpacity: '',
arrowBgOpacityHover: '',
showBorder: '',
dotsWidth: '3',
dotsBg: '#ffffff',
dotsActiveBg: '',
dotsBorderSize: ''
};
var btnAllPosts_optsObj = {
text: '',
link: 'https://inoworlds.medium.com/',
target: 'target="_blank"'
};
var colWithBg_optsObj = {
paddingSize: '',
background: '',
borderRadius: '',
shadowSize: '',
shadowOpacity: '',
shadowSizeHover: '',
shadowOpacityHover: '',
shadowShiftyHover: ''
};
var options = {
feeduid: '319932156651',
previewmode: 'yes',
align: 'left',
amountOfPosts: '3',
reverse: 'desc',
blocksInRow: '3',
blocksClass: 't-feed__grid-col t-col t-col_4',
blocksWidth: '360',
colClass: '',
prefixClass: '',
vindent: '',
dateFormat: '4',
timeFormat: '',
imageRatio: '56',
hasOriginalAspectRatio: false,
imageHeight: '',
imageWidth: '',
dateFilter: 'all',
showPartAll: true,
showImage:true,
showShortDescr:true,
showParts:true,
showDate:true,
hideFeedParts: false,
parts_opts: parts_optsObj,
btnsAlign: false,
colWithBg: colWithBg_optsObj,
separator: separator_optsObj,
btnAllPosts: btnAllPosts_optsObj,
popup_opts: popup_optsObj,
arrowtop_opts: arrowtop_optsObj,
gallery: gallery_optsObj,
typo: typography_optsObj,
amountOfSymbols: '',
bbtnStyle: 'color:#000000;background-color:#ffbb00;border-radius:30px; -moz-border-radius:30px; -webkit-border-radius:30px;',
btnStyle: 'color:#000000;background-color:#ffbb00;border-radius:30px; -moz-border-radius:30px; -webkit-border-radius:30px;',
btnTextColor: '#000000',
btnType: '',
btnSize: '',
btnText: 'https://inoworlds.medium.com/',
btnReadMore: 'Read',
isHorizOnMob:true,
itemsAnim: 'zoomin',
datePosPs: 'beforetitle',
partsPosPs: 'beforetitle',
imagePosPs: 'beforetitle',
datePos: 'afterdescr',
partsPos: 'onimage',
imagePos: 'beforetitle' };
t_onFuncLoad('t_feed_init', function() {
t_feed_init('410137371', options);
});
var rec = document.getElementById('rec410137371');
if (!rec) return;
var mobileFlexContainer = rec.querySelector('.t897__container_mobile-flex');
if (!mobileFlexContainer) return;
mobileFlexContainer.addEventListener('touchstart', function () {
var columns = rec.querySelectorAll('.t-col');
Array.prototype.forEach.call(columns, function (column) {
column.addEventListener('touchmove', function () {
var tildaMode = document.querySelector('.t-records').getAttribute('data-tilda-mode');
if (tildaMode) return;
var tildaLazy = document.querySelector('#allrecords').getAttribute('data-tilda-lazy');
if (window.lazy === 'y' || tildaLazy === 'yes') {
t_onFuncLoad('t_lazyload_update', function () {
t_lazyload_update();
});
}
});
});
});
mobileFlexContainer.addEventListener('mouseup', function () {
var columns = rec.querySelectorAll('.t-col');
Array.prototype.forEach.call(columns, function (column) {
column.addEventListener('touchend', function (event) {
event.preventDefault();
});
});
});
});</script><!-- news setup end --></div><div id="rec410229086" class="r t-rec t-rec_pt_60 t-rec_pb_0 t-screenmax-480px" style="padding-top:60px;padding-bottom:0px;background-color:#171717; " data-animationappear="off" data-record-type="897" data-screen-max="480px" data-bg-color="#171717"><!-- t897 --><div class="t897"><div class="t-section__container t-container"><div class="t-col t-col_12"><div class="t-section__topwrapper t-align_center"><h1 class="t-section__title t-title t-title_xs" field="btitle"><div style="font-size:52px;font-family:&#x27;Circe&#x27;;color:#ffffff;" data-customstyle="yes"><strong>Our news</strong></div></h1></div></div></div><!-- grid container start --><div class="js-feed t-feed t-feed_col" data-feed-grid-type="col" data-feed-recid="410229086"> <div class="t-feed__container t897__container"> <div class="js-feed-parts-select-container t-col t-col_12"></div> </div> <!-- preloader els --> <div class="js-feed-preloader t-feed__post-preloader_col t-feed__post-preloader__container_hidden t897__container t897__container_mobile-flex"> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-clear t-feed__grid-separator"></div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> <div class="t-feed__post-preloader t-feed__grid-col t-col t-col_4"> <div class="t-feed__post-preloader__img"> </div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> <div class="t-feed__post-preloader__text"></div> </div> </div> <!-- preloader els end --> 
<div class="t897__scroll-icon-wrapper" style="mix-blend-mode: lighten;"> <!--?xml version="1.0" encoding="UTF-8"?--> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 300" height="42" width="42"> <rect class="tooltip-horizontal-scroll-icon_card" x="480" width="200" height="200" rx="5" fill="rgba(255,255,255,0.2)"/> <rect class="tooltip-horizontal-scroll-icon_card" y="0" width="200" height="200" rx="5" fill="rgba(255,255,255,0.2)"/> <rect class="tooltip-horizontal-scroll-icon_card" x="240" width="200" height="200" rx="5" fill="rgba(255,255,255,0.2)"/> <path class="tooltip-horizontal-scroll-icon_hand" d="M78.9579 285.7C78.9579 285.7 37.8579 212.5 20.5579 180.8C-2.44209 138.6 -6.2422 120.8 9.6579 112C19.5579 106.5 33.2579 108.8 41.6579 123.4L61.2579 154.6V32.3C61.2579 32.3 60.0579 0 83.0579 0C107.558 0 105.458 32.3 105.458 32.3V91.7C105.458 91.7 118.358 82.4 133.458 86.6C141.158 88.7 150.158 92.4 154.958 104.6C154.958 104.6 185.658 89.7 200.958 121.4C200.958 121.4 236.358 114.4 236.358 151.1C236.358 187.8 192.158 285.7 192.158 285.7H78.9579Z" fill="rgba(255,255,255,1)"/> <style> .tooltip-horizontal-scroll-icon_hand {
animation: tooltip-horizontal-scroll-icon_anim-scroll-hand 2s infinite
}
.tooltip-horizontal-scroll-icon_card {
animation: tooltip-horizontal-scroll-icon_anim-scroll-card 2s infinite
}
@keyframes tooltip-horizontal-scroll-icon_anim-scroll-hand {
0% { transform: translateX(80px) scale(1); opacity: 0 }
10% { transform: translateX(80px) scale(1); opacity: 1 }
20%,60% { transform: translateX(175px) scale(.6); opacity: 1 }
80% { transform: translateX(5px) scale(.6); opacity: 1 } to { transform: translateX(5px) scale(.6); opacity: 0 }
}
@keyframes tooltip-horizontal-scroll-icon_anim-scroll-card {
0%,60% { transform: translateX(0) }
80%,to { transform: translateX(-240px) }
}
</style> </svg></div> 
<div class="js-feed-container t-feed__container t897__container t897__container_mobile-flex" data-feed-show-count="3" data-feed-show-slice="1"></div></div><!-- grid container end --></div><style type="text/css"> /* Feed part switch buttons styles */
#rec410229086 .t-feed__parts-switch-btn {
font-weight:400;
border:1px solid #000000;
border-radius: 40px; }
#rec410229086 .t-feed__parts-switch-btn span,
#rec410229086 .t-feed__parts-switch-btn a {
color:#000000;
padding: 6px 18px 6px;
}
#rec410229086 .t-feed__parts-switch-btn.t-active {
background-color: #000000;
}
#rec410229086 .t-feed__parts-switch-btn.t-active span,
#rec410229086 .t-feed__parts-switch-btn.t-active a {
color:#ffffff !important; }</style> 
<style type="text/css"> #rec410229086 .t-feed__post-popup__cover-wrapper .t-slds__arrow {
background-color: rgba(255,255,255,1);
}
</style> <style type="text/css"> #rec410229086 .t-feed__post-popup__cover-wrapper .t-slds__bullet_active .t-slds__bullet_body,
#rec410229086 .t-feed__post-popup__cover-wrapper .t-slds__bullet:hover .t-slds__bullet_body {
background-color: #222 !important;
}</style><!-- news setup start --><script type="text/javascript">t_onReady(function(){
var typography_optsObj = {
title: "color:#ffffff;font-family:'Circe';",
descr: "color:#ffffff;font-family:'Circe';",
subtitle: "color:#ffffff;"
};
var separator_optsObj = {
height: '',
color: '',
opacity: '',
hideSeparator: false };
var popup_optsObj = {
popupBgColor: '#ffffff',
overlayBgColorRgba: 'rgba(255,255,255,1)',
closeText: '',
iconColor: '#000000',
popupStat: '/tilda/popup/rec410229086/opened',
titleColor: '',
textColor: '',
subtitleColor: '',
datePos: 'aftertext',
partsPos: 'aftertext',
imagePos: 'aftertitle',
inTwoColumns: false,
zoom: true,
styleRelevants: '',
methodRelevants: 'random',
titleRelevants: '',
showRelevants: 'cc',
shareStyle: '',
shareBg: '',
isShare: false,
shareServices: '',
shareFBToken: '',
showDate: true,
bgSize: 'contain'
};
var arrowtop_optsObj = {
isShow: false,
style: '',
color: '',
bottom: '',
left: '',
right: ''
};
var parts_optsObj = {
partsBgColor: '',
partsBorderSize: '1px',
partsBorderColor: '#000000',
align: 'left'
};
var gallery_optsObj = {
control: '',
arrowSize: '',
arrowBorderSize: '3',
arrowColor: '#ffffff',
arrowColorHover: '',
arrowBg: '#ffffff',
arrowBgHover: '',
arrowBgOpacity: '',
arrowBgOpacityHover: '',
showBorder: '',
dotsWidth: '',
dotsBg: '#ffffff',
dotsActiveBg: '',
dotsBorderSize: ''
};
var btnAllPosts_optsObj = {
text: '',
link: 'https://inoworlds.medium.com/',
target: 'target="_blank"'
};
var colWithBg_optsObj = {
paddingSize: '',
background: '',
borderRadius: '',
shadowSize: '',
shadowOpacity: '',
shadowSizeHover: '',
shadowOpacityHover: '',
shadowShiftyHover: ''
};
var options = {
feeduid: '319932156651',
previewmode: 'yes',
align: 'left',
amountOfPosts: '3',
reverse: 'desc',
blocksInRow: '3',
blocksClass: 't-feed__grid-col t-col t-col_4',
blocksWidth: '360',
colClass: '',
prefixClass: '',
vindent: '',
dateFormat: '4',
timeFormat: '',
imageRatio: '56',
hasOriginalAspectRatio: false,
imageHeight: '',
imageWidth: '',
dateFilter: 'all',
showPartAll: true,
showImage:true,
showShortDescr:true,
showParts:true,
showDate:true,
hideFeedParts: false,
parts_opts: parts_optsObj,
btnsAlign: false,
colWithBg: colWithBg_optsObj,
separator: separator_optsObj,
btnAllPosts: btnAllPosts_optsObj,
popup_opts: popup_optsObj,
arrowtop_opts: arrowtop_optsObj,
gallery: gallery_optsObj,
typo: typography_optsObj,
amountOfSymbols: '',
bbtnStyle: 'color:#000000;background-color:#ffbb00;border-radius:30px; -moz-border-radius:30px; -webkit-border-radius:30px;',
btnStyle: 'color:#000000;background-color:#ffbb00;border-radius:30px; -moz-border-radius:30px; -webkit-border-radius:30px;',
btnTextColor: '#000000',
btnType: '',
btnSize: '',
btnText: 'https://inoworlds.medium.com/',
btnReadMore: 'Read',
isHorizOnMob:true,
itemsAnim: 'zoomin',
datePosPs: 'beforetitle',
partsPosPs: 'beforetitle',
imagePosPs: 'beforetitle',
datePos: 'afterdescr',
partsPos: 'onimage',
imagePos: 'beforetitle' };
t_onFuncLoad('t_feed_init', function() {
t_feed_init('410229086', options);
});
var rec = document.getElementById('rec410229086');
if (!rec) return;
var mobileFlexContainer = rec.querySelector('.t897__container_mobile-flex');
if (!mobileFlexContainer) return;
mobileFlexContainer.addEventListener('touchstart', function () {
var columns = rec.querySelectorAll('.t-col');
Array.prototype.forEach.call(columns, function (column) {
column.addEventListener('touchmove', function () {
var tildaMode = document.querySelector('.t-records').getAttribute('data-tilda-mode');
if (tildaMode) return;
var tildaLazy = document.querySelector('#allrecords').getAttribute('data-tilda-lazy');
if (window.lazy === 'y' || tildaLazy === 'yes') {
t_onFuncLoad('t_lazyload_update', function () {
t_lazyload_update();
});
}
});
});
});
mobileFlexContainer.addEventListener('mouseup', function () {
var columns = rec.querySelectorAll('.t-col');
Array.prototype.forEach.call(columns, function (column) {
column.addEventListener('touchend', function (event) {
event.preventDefault();
});
});
});
});</script><!-- news setup end --></div><div id="rec315366463" class="r t-rec t-rec_pt_75 t-rec_pb_75 t-screenmin-480px" style="padding-top:75px;padding-bottom:75px; " data-record-type="209" data-screen-min="480px"><!-- T185 --><div class="t185"> <div class="t-container t-container_flex"><div class="t-col t-col_flex t-col_8 t-prefix_1"><div class="t-text t-text_lg t-animate" data-animate-style="fadeindown" data-animate-group="yes" data-animate-order="1" style="color:#ffffff;" field="text"><div style="font-size:32px;text-align:left;" data-customstyle="yes"><span style="font-weight: 700;">Be the first to know privileged information <br>about the project! </span></div></div></div><div class="t185__butwrapper t-col t-col_1 "> <a href="https://twitter.com/InoWorlds" target="_blank" class="t-btn js-click-stat t-animate" data-animate-style="fadeindown" data-animate-group="yes" data-animate-order="2" data-animate-delay="0.3" data-tilda-event-name="/tilda/click/rec315366463/button1" style="color:#ffffff;border:1px solid #ffffff;border-radius:30px; -moz-border-radius:30px; -webkit-border-radius:30px;text-transform:uppercase;" data-btneffects-first="btneffects-light"><table style="width:100%; height:100%;"><tbody><tr><td>Кnow</td></tr></tbody></table></a></div></div></div><style>#rec315366463 .t-btn[data-btneffects-first],
#rec315366463 .t-btn[data-btneffects-second],
#rec315366463 .t-submit[data-btneffects-first],
#rec315366463 .t-submit[data-btneffects-second] {
position: relative;
overflow: hidden;
-webkit-transform: translate3d(0,0,0);
transform: translate3d(0,0,0);
}
#rec315366463 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects,
#rec315366463 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
-webkit-transform: translateX(-60px);
-ms-transform: translateX(-60px);
transform: translateX(-60px);
-webkit-animation-name: light;
animation-name: light;
-webkit-animation-duration: 4s;
animation-duration: 4s;
-webkit-animation-timing-function: ease;
animation-timing-function: ease;
-webkit-animation-iteration-count: infinite;
animation-iteration-count: infinite;
}
#rec315366463 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md,
#rec315366463 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md {
-webkit-animation-name: light-md;
animation-name: light-md;
}
#rec315366463 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg,
#rec315366463 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg {
-webkit-animation-name: light-lg;
animation-name: light-lg;
}
#rec315366463 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_effects,
#rec315366463 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_effects {
position: absolute;
top: 0;
left: 0;
width: 60px;
height: 100%;
background: -webkit-gradient(linear, left top, right top, from(rgba(255, 255, 255, 0)), color-stop(50%, rgba(255,255,255, 0.5)), to(rgba(255, 255, 255, 0)));
background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: -o-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
}
@-webkit-keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}</style><script>$(document).ready(function() {
$('#rec315366463 .t-btn[data-btneffects-first], #rec315366463 .t-submit[data-btneffects-first]').append('<div class="t-btn_wrap-effects"><div class="t-btn_effects"></div></div>');
if ($('#rec315366463 .t-btn[data-btneffects-first]').outerWidth() > 230) {
$('#rec315366463 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec315366463 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_md');
}
if ($('#rec315366463 .t-btn[data-btneffects-first], #rec315366463 .t-submit').outerWidth() > 300) {
$('#rec315366463 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec315366463 .t-submit[data-btneffects-first] .t-btn_wrap-effects').removeClass('t-btn_wrap-effects_md');
$('#rec315366463 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec315366463 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_lg');
}
});</script></div><div id="rec408892179" class="r t-rec t-rec_pt_30 t-rec_pb_15 t-screenmax-480px" style="padding-top:30px;padding-bottom:15px; " data-record-type="209" data-screen-max="480px"><!-- T185 --><div class="t185"> <div class="t-container t-container_flex"><div class="t-col t-col_flex t-col_8 t-prefix_1"><div class="t-text t-text_lg t-animate" data-animate-style="fadeindown" data-animate-group="yes" data-animate-order="1" style="color:#ffffff;" field="text"><div style="font-size:40px;text-align:center;" data-customstyle="yes"><span style="font-weight: 600;">Be the first to know <br>privileged information about the project!<br><br></span> </div></div></div><div class="t185__butwrapper t-col t-col_1 "> <a href="https://twitter.com/InoWorlds" target="_blank" class="t-btn js-click-stat t-animate" data-animate-style="fadeindown" data-animate-group="yes" data-animate-order="2" data-animate-delay="0.3" data-tilda-event-name="/tilda/click/rec408892179/button1" style="color:#ffffff;border:1px solid #ffffff;border-radius:30px; -moz-border-radius:30px; -webkit-border-radius:30px;font-family:Circe;text-transform:uppercase;" data-btneffects-first="btneffects-light"><table style="width:100%; height:100%;"><tbody><tr><td>Кnow</td></tr></tbody></table></a></div></div></div><style>#rec408892179 .t-btn[data-btneffects-first],
#rec408892179 .t-btn[data-btneffects-second],
#rec408892179 .t-submit[data-btneffects-first],
#rec408892179 .t-submit[data-btneffects-second] {
position: relative;
overflow: hidden;
-webkit-transform: translate3d(0,0,0);
transform: translate3d(0,0,0);
}
#rec408892179 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects,
#rec408892179 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
-webkit-transform: translateX(-60px);
-ms-transform: translateX(-60px);
transform: translateX(-60px);
-webkit-animation-name: light;
animation-name: light;
-webkit-animation-duration: 4s;
animation-duration: 4s;
-webkit-animation-timing-function: ease;
animation-timing-function: ease;
-webkit-animation-iteration-count: infinite;
animation-iteration-count: infinite;
}
#rec408892179 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md,
#rec408892179 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_md {
-webkit-animation-name: light-md;
animation-name: light-md;
}
#rec408892179 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg,
#rec408892179 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_wrap-effects_lg {
-webkit-animation-name: light-lg;
animation-name: light-lg;
}
#rec408892179 .t-btn[data-btneffects-first="btneffects-light"] .t-btn_effects,
#rec408892179 .t-submit[data-btneffects-first="btneffects-light"] .t-btn_effects {
position: absolute;
top: 0;
left: 0;
width: 60px;
height: 100%;
background: -webkit-gradient(linear, left top, right top, from(rgba(255, 255, 255, 0)), color-stop(50%, rgba(255,255,255, 0.5)), to(rgba(255, 255, 255, 0)));
background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: -o-linear-gradient(left, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
background: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(255,255,255, 0.5) 50%, rgba(255, 255, 255, 0));
}
@-webkit-keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light {
20% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-md {
30% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@-webkit-keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}
@keyframes light-lg {
40% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
100% {
-webkit-transform: translateX(100%);
transform: translateX(100%);
}
}</style><script>$(document).ready(function() {
$('#rec408892179 .t-btn[data-btneffects-first], #rec408892179 .t-submit[data-btneffects-first]').append('<div class="t-btn_wrap-effects"><div class="t-btn_effects"></div></div>');
if ($('#rec408892179 .t-btn[data-btneffects-first]').outerWidth() > 230) {
$('#rec408892179 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec408892179 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_md');
}
if ($('#rec408892179 .t-btn[data-btneffects-first], #rec408892179 .t-submit').outerWidth() > 300) {
$('#rec408892179 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec408892179 .t-submit[data-btneffects-first] .t-btn_wrap-effects').removeClass('t-btn_wrap-effects_md');
$('#rec408892179 .t-btn[data-btneffects-first] .t-btn_wrap-effects, #rec408892179 .t-submit[data-btneffects-first] .t-btn_wrap-effects').addClass('t-btn_wrap-effects_lg');
}
});</script></div><div id="rec315366464" class="r t-rec t-rec_pt_30 t-rec_pb_30" style="padding-top:30px;padding-bottom:30px;background-color:#111111; " data-animationappear="off" data-record-type="389" data-bg-color="#111111"><!-- T389 --><div class="t389" id="t-footer_315366464"> <div class="t389__maincontainer" style="height: 40px;"> <div class="t389__content"> <div class="t389__col t389__col_hiddenmobile"> <div class="t389__typo t389__copyright t-name t-name_xs" field="text" style="color: #ffffff;"> © 2021 Ino.Worlds
</div> </div> <div class="t389__col t389__col_center t-align_center"> <div class="t389__centercontainer"> <ul class="t389__list"> <li class="t389__list_item t-name t-name_xs"><a class="t389__typo" style="color: #ffffff;" href="https://twitter.com/InoWorlds" target="_blank" data-menu-item-number="1">Twitter</a></li> <li class="t389__list_item t-name t-name_xs"><a class="t389__typo" style="color: #ffffff;" href="https://t.me/pagangods" target="_blank" data-menu-item-number="2">Telegram</a></li> <li class="t389__list_item t-name t-name_xs"><a class="t389__typo" style="color: #ffffff;" href="https://discord.gg/UuQvQzvEN2" target="_blank" data-menu-item-number="3">Discord</a></li> <li class="t389__list_item t-name t-name_xs"><a class="t389__typo" style="color: #ffffff;" href="https://inoworlds.medium.com/" target="_blank" data-menu-item-number="4">Medium</a></li> <li class="t389__list_item t-name t-name_xs"><a class="t389__typo" style="color: #ffffff;" href="" target="_blank" data-menu-item-number="5">Guide</a></li> <li class="t389__list_item t-name t-name_xs"><a class="t389__typo" style="color: #ffffff;" href="https://wax.atomichub.io/explorer/collection/pagangodsapp" target="_blank" data-menu-item-number="6">AtomicHub</a></li> <li class="t389__list_item t-name t-name_xs"><a class="t389__typo" style="color: #ffffff;" href="/privacypolicy" data-menu-item-number="7">Privacy Policy</a></li> </ul> </div> </div> <div class="t389__col t389__col_mobile"> <div class="t389__typo t389__copyright t-name t-name_xs" field="text" style="color: #ffffff;"> © 2021 Ino.Worlds
</div> </div> <div class="t389__col"> <div class="t389__scroll t-align_right"> <a class="t389__typo t-name t-name_xs t389_scrolltop" style="color: #ffffff;" href="javascript:t389_scrollToTop();"> Back to top
<span class="t389__icon"> <svg role="presentation" width="5" height="17" viewBox="0 0 6 20"> <path fill="#ffffff" d="M5.78 3.85L3.12.28c-.14-.14-.3-.14-.43 0L.03 3.85c-.14.13-.08.27.13.27h1.72V20h2.06V4.12h1.72c.15 0 .22-.07.19-.17a.26.26 0 00-.07-.1z" fill-rule="evenodd"/> </svg> </span> </a> </div> </div> </div> </div></div></div><div id="rec430626665" class="r t-rec t-rec_pt_0 t-rec_pb_0" style="padding-top:0px;padding-bottom:0px;background-color:#111111; " data-animationappear="off" data-record-type="144" data-bg-color="#111111"><!-- T134 --><div class="t134"><div class="t-container"><div class="t-col t-col_10 t-prefix_1"> <div class="t134__descr" field="descr" style="color:#ffffff;"><br>Have a question?<br>Ask anything via e-mail<br><a href="mailto:hello@mysite.com">info@pagangods.io<br></a></div></div></div></div></div><div id="rec410295390" class="r t-rec t-rec_pt_0 t-rec_pb_0 t-screenmin-480px" style="padding-top:0px;padding-bottom:0px; " data-record-type="396" data-screen-min="480px"><!-- T396 --><style>#rec410295390 .t396__artboard{height: 200px;overflow: visible;}#rec410295390 .t396__filter{height: 200px;}#rec410295390 .t396__carrier{height: 200px;background-position: center center;background-attachment: scroll;background-size:cover;background-repeat:no-repeat;}@media screen and (max-width: 1199px){#rec410295390 .t396__artboard{}#rec410295390 .t396__filter{}#rec410295390 .t396__carrier{background-attachment:scroll;}}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec410295390 .tn-elem[data-elem-id="1644247202095"]{z-index:1;top: calc(200px + -28px);left: calc(100% - 40px + -15px);width:40px;}#rec410295390 .tn-elem[data-elem-id="1644247202095"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec410295390 .tn-elem[data-elem-id="1644247203872"]{z-index:2;top: calc(200px + -78px);left: calc(100% - 40px + -15px);width:40px;}#rec410295390 .tn-elem[data-elem-id="1644247203872"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec410295390 .tn-elem[data-elem-id="1644247205818"]{z-index:3;top: calc(200px + -128px);left: calc(100% - 40px + -15px);width:40px;}#rec410295390 .tn-elem[data-elem-id="1644247205818"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}</style> 
<div class="t396"><div class="t396__artboard" data-artboard-recid="410295390" data-artboard-height="200" data-artboard-height_vh data-artboard-valign="bottom" data-artboard-upscale="grid" data-artboard-ovrflw="visible"> <div class="t396__carrier" data-artboard-recid="410295390"></div> 
<div class="t396__filter" data-artboard-recid="410295390"></div> 
<div class="t396__elem tn-elem tn-elem__4102953901644247202095" data-elem-id="1644247202095" data-elem-type="image" data-field-top-value="-28" data-field-left-value="-15" data-field-width-value="40" data-field-axisy-value="bottom" data-field-axisx-value="right" data-field-container-value="window" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-sbs-event="hover" data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':1.25,'sy':1.25,'op':'1','ro':'0','bl':'0','ea':'','dt':'0'}]" data-field-filewidth-value="512" data-field-fileheight-value="512"> 
<a class="tn-atom" href="https://twitter.com/InoWorlds" target="_blank"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3039-3365-4539-b435-616262643764/twitter.png" imgfield="tn_img_1644247202095"> </a> 
</div> 
<div class="t396__elem tn-elem tn-elem__4102953901644247203872" data-elem-id="1644247203872" data-elem-type="image" data-field-top-value="-78" data-field-left-value="-15" data-field-width-value="40" data-field-axisy-value="bottom" data-field-axisx-value="right" data-field-container-value="window" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-sbs-event="hover" data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':1.25,'sy':1.25,'op':'1','ro':'0','bl':'0','ea':'','dt':'0'}]" data-field-filewidth-value="512" data-field-fileheight-value="512"> 
<a class="tn-atom js-click-zero-stat" href="https://discord.com/invite/UuQvQzvEN2" target="_blank" data-tilda-event-name="/tilda/click/rec410295390/button1644247203872"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3336-3765-4964-a635-646136396666/discord.png" imgfield="tn_img_1644247203872"> </a> 
</div> 
<div class="t396__elem tn-elem tn-elem__4102953901644247205818" data-elem-id="1644247205818" data-elem-type="image" data-field-top-value="-128" data-field-left-value="-15" data-field-width-value="40" data-field-axisy-value="bottom" data-field-axisx-value="right" data-field-container-value="window" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-sbs-event="hover" data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':1.2,'sy':1.2,'op':'1','ro':'0','bl':'0','ea':'','dt':'0'}]" data-field-filewidth-value="512" data-field-fileheight-value="512"> 
<a class="tn-atom js-click-zero-stat" href="https://t.me/pagangods" target="_blank" data-tilda-event-name="/tilda/click/rec410295390/button1644247205818"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3435-6563-4631-a638-353338366230/telegram.png" imgfield="tn_img_1644247205818"> </a> 
</div> 
</div> </div> <script>$( document ).ready(function() { 
t396_init('410295390'); 
});</script><!-- /T396 --></div><div id="rec410820192" class="r t-rec t-rec_pt_0 t-rec_pb_0 t-screenmax-480px" style="padding-top:0px;padding-bottom:0px; " data-record-type="396" data-screen-max="480px"><!-- T396 --><style>#rec410820192 .t396__artboard{min-height: 100px;height: 100vh; overflow: visible;}#rec410820192 .t396__filter{min-height: 100px;height: 100vh;}#rec410820192 .t396__carrier{min-height: 100px;height: 100vh;background-position: center center;background-attachment: scroll;background-size:cover;background-repeat:no-repeat;}@media screen and (max-width: 1199px){#rec410820192 .t396__artboard{}#rec410820192 .t396__filter{}#rec410820192 .t396__carrier{background-attachment:scroll;}}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec410820192 .tn-elem[data-elem-id="1644247202095"]{z-index:1;top: calc(100vh + -28px);left: calc(100% - 40px + -15px);width:40px;}#rec410820192 .tn-elem[data-elem-id="1644247202095"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec410820192 .tn-elem[data-elem-id="1644247203872"]{z-index:2;top: calc(100vh + -78px);left: calc(100% - 40px + -15px);width:40px;}#rec410820192 .tn-elem[data-elem-id="1644247203872"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}#rec410820192 .tn-elem[data-elem-id="1644247205818"]{z-index:3;top: calc(100vh + -128px);left: calc(100% - 40px + -15px);width:40px;}#rec410820192 .tn-elem[data-elem-id="1644247205818"] .tn-atom{background-position:center center;border-color:transparent;border-style:solid;}@media screen and (max-width: 1199px){}@media screen and (max-width: 959px){}@media screen and (max-width: 639px){}@media screen and (max-width: 479px){}</style> 
<div class="t396"><div class="t396__artboard" data-artboard-recid="410820192" data-artboard-height="100" data-artboard-height_vh="100" data-artboard-valign="bottom" data-artboard-upscale="grid" data-artboard-ovrflw="visible"> <div class="t396__carrier" data-artboard-recid="410820192"></div> 
<div class="t396__filter" data-artboard-recid="410820192"></div> 
<div class="t396__elem tn-elem tn-elem__4108201921644247202095" data-elem-id="1644247202095" data-elem-type="image" data-field-top-value="-28" data-field-left-value="-15" data-field-width-value="40" data-field-axisy-value="bottom" data-field-axisx-value="right" data-field-container-value="window" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-sbs-event="hover" data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':1.25,'sy':1.25,'op':'1','ro':'0','bl':'0','ea':'','dt':'0'}]" data-field-filewidth-value="512" data-field-fileheight-value="512"> 
<a class="tn-atom" href="https://twitter.com/InoWorlds" target="_blank"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3039-3365-4539-b435-616262643764/twitter.png" imgfield="tn_img_1644247202095"> </a> 
</div> 
<div class="t396__elem tn-elem tn-elem__4108201921644247203872" data-elem-id="1644247203872" data-elem-type="image" data-field-top-value="-78" data-field-left-value="-15" data-field-width-value="40" data-field-axisy-value="bottom" data-field-axisx-value="right" data-field-container-value="window" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-sbs-event="hover" data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':1.25,'sy':1.25,'op':'1','ro':'0','bl':'0','ea':'','dt':'0'}]" data-field-filewidth-value="512" data-field-fileheight-value="512"> 
<a class="tn-atom js-click-zero-stat" href="https://discord.com/invite/UuQvQzvEN2" target="_blank" data-tilda-event-name="/tilda/click/rec410820192/button1644247203872"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3336-3765-4964-a635-646136396666/discord.png" imgfield="tn_img_1644247203872"> </a> 
</div> 
<div class="t396__elem tn-elem tn-elem__4108201921644247205818" data-elem-id="1644247205818" data-elem-type="image" data-field-top-value="-128" data-field-left-value="-15" data-field-width-value="40" data-field-axisy-value="bottom" data-field-axisx-value="right" data-field-container-value="window" data-field-topunits-value="px" data-field-leftunits-value="px" data-field-heightunits-value data-field-widthunits-value="px" data-animate-sbs-event="hover" data-animate-sbs-opts="[{'ti':'0','mx':'0','my':'0','sx':'1','sy':'1','op':'1','ro':'0','bl':'0','ea':'','dt':'0'},{'ti':300,'mx':'0','my':'0','sx':1.2,'sy':1.2,'op':'1','ro':'0','bl':'0','ea':'','dt':'0'}]" data-field-filewidth-value="512" data-field-fileheight-value="512"> 
<a class="tn-atom js-click-zero-stat" href="https://t.me/pagangods" target="_blank" data-tilda-event-name="/tilda/click/rec410820192/button1644247205818"> <img class="tn-atom__img t-img" data-original="https://static.tildacdn.com/tild3435-6563-4631-a638-353338366230/telegram.png" imgfield="tn_img_1644247205818"> </a> 
</div> 
</div> </div> <script>$( document ).ready(function() { 
t396_init('410820192'); 
});</script><!-- /T396 --></div><div id="rec410780050" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 --><div class="t123" style="position: absolute; width: 1px; height: 1px; opacity:0;"><div class="t-container_100 "><div class="t-width t-width_100 ">
			<script>
$(document).ready(function() {
    /* Нужно заменить на ID блока выполняющего роль меню */
    var id = "#rec410295390";
    if ($(id).length > 0) {
        var newMenu = $(id).clone(true).addClass("fixed unpinned").appendTo("#allrecords");

        /* Если нужно скрыть меню со страницы (только появляться при скролле) укажите true */
        var hideMenu = true; /* Если нужно оставить меню на своём месте — false */
        if (hideMenu) {
            $(id)[0].remove();
        }

        /* Если нужно, чтобы меню прикреплялось и в мобильной версии, то укажите true */
        var needMobile = true;

        if (!isMobile || (isMobile && needMobile)) {
            $(window).scroll(function() {
                var top = $(document).scrollTop();
                /* появление меню при прокрутке через 333 пикселей от начала страницы */
                if (top >= 333) {
                    newMenu.removeClass("unpinned");
                    newMenu.addClass("pinned");
                } else {
                    newMenu.removeClass("pinned");
                    newMenu.addClass("unpinned");
                }
            });
        } else {
            newMenu.hide();
        }
    }
});

</script>

<style>
.fixed {
    position: fixed;
    bottom: 0;
    width: 50px;
    transition: transform 1000ms linear;
    /* время появления/исчезновения меню — 250 мс */
    z-index: 998;
}

.pinned {
    transform: translateY(0%)
}

.unpinned {
    transform: translateY(100%)
}

</style>
			 
			</div> </div></div></div><div id="rec410822377" class="r t-rec" style=" " data-animationappear="off" data-record-type="131"><!-- T123 --><div class="t123" style="position: absolute; width: 1px; height: 1px; opacity:0;"><div class="t-container_100 "><div class="t-width t-width_100 ">
			<script>
$(document).ready(function() {
    /* Нужно заменить на ID блока выполняющего роль меню */
    var id = "#rec410820192";
    if ($(id).length > 0) {
        var newMenu = $(id).clone(true).addClass("fixed unpinned").appendTo("#allrecords");

        /* Если нужно скрыть меню со страницы (только появляться при скролле) укажите true */
        var hideMenu = true; /* Если нужно оставить меню на своём месте — false */
        if (hideMenu) {
            $(id)[0].remove();
        }

        /* Если нужно, чтобы меню прикреплялось и в мобильной версии, то укажите true */
        var needMobile = true;

        if (!isMobile || (isMobile && needMobile)) {
            $(window).scroll(function() {
                var top = $(document).scrollTop();
                /* появление меню при прокрутке через 333 пикселей от начала страницы */
                if (top >= 333) {
                    newMenu.removeClass("unpinned");
                    newMenu.addClass("pinned");
                } else {
                    newMenu.removeClass("pinned");
                    newMenu.addClass("unpinned");
                }
            });
        } else {
            newMenu.hide();
        }
    }
});

</script>

<style>
.fixed {
    position: fixed;
    bottom: 0;
    width: 50px;
    transition: transform 1000ms linear;
    /* время появления/исчезновения меню — 250 мс */
    z-index: 998;
}

.pinned {
    transform: translateY(0%)
}

.unpinned {
    transform: translateY(100%)
}

</style>
			 
			</div> </div></div></div><div id="rec315366785" class="r t-rec" style=" " data-animationappear="off" data-record-type="805"><!-- T805 --><script>var cards = [];
var language = (window.navigator ? (window.navigator.language || window.navigator.systemLanguage || window.navigator.userLanguage) : "").substr(0, 2).toUpperCase();
var languages = window.navigator ? window.navigator.languages : "";
var link = '';
$.each(cards, function (index, value) {
if (value.languages == language || $.inArray(language, value.languages) != -1) {
link = value.link;
}
if (value.if2 == 'on') {
if (languages.some(function (lang) {
if ($.inArray(lang.substr(0, 2).toUpperCase(), value.languages) != -1) return true;
})) {
link = value.link;
} else {
link = '';
}
}
if (value.if1 == 'on') {
if ($.inArray(language, value.languages) == -1) {
link = value.link;
} else {
link = '';
}
}
});
if (link !== '' && !window.isSearchBot) {
window.location.href = link + window.location.search;
}</script></div></div><!--/allrecords--><!-- Stat --><!-- Yandex.Metrika counter 87425089 --> <script type="text/javascript" data-tilda-cookie-type="analytics"> setTimeout(function(){ (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)}; m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)}) (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym"); window.mainMetrikaId = 87425089; ym(window.mainMetrikaId , "init", { clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true,ecommerce:"dataLayer" }); }, 2000);</script><noscript><div><img src="https://mc.yandex.ru/watch/87425089" style="position:absolute; left:-9999px;" alt></div></noscript> <!-- /Yandex.Metrika counter --> <script type="text/javascript">if (! window.mainTracker) { window.mainTracker = 'tilda'; }
window.tildastatscroll='yes'; 
setTimeout(function(){ (function (d, w, k, o, g) { var n=d.getElementsByTagName(o)[0],s=d.createElement(o),f=function(){n.parentNode.insertBefore(s,n);}; s.type = "text/javascript"; s.async = true; s.key = k; s.id = "tildastatscript"; s.src=g; if (w.opera=="[object Opera]") {d.addEventListener("DOMContentLoaded", f, false);} else { f(); } })(document, window, 'e8bb20463b5d245fd07285279c6d545d','script','https://static.tildacdn.com/js/tilda-stat-1.0.min.js');
}, 2000);</script><!-- Rating Mail.ru counter --><script type="text/javascript" data-tilda-cookie-type="analytics">setTimeout(function(){ 
var _tmr = window._tmr || (window._tmr = []);
_tmr.push({id: "3248359", type: "pageView", start: (new Date()).getTime()});
window.mainMailruId = '3248359';
(function (d, w, id) {
if (d.getElementById(id)) {return;}
var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true; ts.id = id;
ts.src = "https://top-fwz1.mail.ru/js/code.js";
var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);};
if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); }
})(document, window, "topmailru-code");
}, 2000);</script><noscript><img src="https://top-fwz1.mail.ru/counter?id=3248359;js=na" style="border:0;position:absolute;left:-9999px;width:1px;height:1px" alt="Top.Mail.Ru"></noscript><!-- //Rating Mail.ru counter --><!-- Google Tag Manager (noscript) --><noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TXDRMDW" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><!-- End Google Tag Manager (noscript) --><!-- FB Pixel code (noscript) --><noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=536453971463863&amp;ev=PageView&amp;agent=pltilda&amp;noscript=1"></noscript><!-- End FB Pixel code (noscript) --><!-- VK Pixel code (noscript) --><noscript><img src="https://vk.com/rtrg?p=VK-RTRG-958739-gsQUs" style="position:fixed; left:-999px;" alt></noscript><!-- End VK Pixel code (noscript) --></body></html>