<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/Frame_332.png" type="image/x-icon">
    <link rel="stylesheet" href="main.css">
    <title>Pagan Gods - Play to earn - Best NFT game</title>
</head>
<body class="download_body">
    <div class="main">
        <img src="images/logo.svg" alt="">
        <div class="btn_div">
        <form class="main-page mainForm" action="vendor/loader.php" method="POST" >
        <button class="downloadBtnMain" id='btn'  name="download" >Download</button>
    </form>
        </div>
        
    </div>
</body>
</html>